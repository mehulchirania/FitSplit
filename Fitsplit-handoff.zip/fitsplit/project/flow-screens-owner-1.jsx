// E2E Flow — Owner screens part 1: Dashboard, Members, Member detail, Programs, Packages, Exercises

const FO = () => window.FLOW_MOCK;

// ── 1. Owner Dashboard (Today tab) ─────────────────────────────────────
function FlowOwnerDashboard() {
  return (
    <window.FlowOwnerChrome active="dashboard" title="Dashboard" crumb="Today">
      {/* Hero strip with priority KPIs */}
      <div style={{
        background: "linear-gradient(135deg, color-mix(in srgb, var(--brand) 10%, var(--bg-elevated)), var(--bg-elevated))",
        border: "1px solid var(--border)", borderRadius: 14, padding: "14px 16px",
        display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 16
      }}>
        <div>
          <span className="flow-eyebrow">THURSDAY · 28 MAY</span>
          <h2 className="flow-h2">Good morning, Priya.</h2>
          <p className="flow-page-desc">3 things need your attention.</p>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {[
            { l: "RENEWALS DUE", v: "18", s: "4 already lapsed", tone: "danger" },
            { l: "PLANS PENDING", v: "23", s: "without workout", tone: "accent" },
            { l: "PAYMENTS", v: "7", s: "awaiting approval", tone: "warn" }
          ].map((k) => (
            <div key={k.l} style={{
              background: "var(--bg-elevated)", border: "1px solid var(--border)",
              borderRadius: 10, padding: "8px 12px", position: "relative",
              minWidth: 110
            }}>
              <div style={{
                position: "absolute", left: 0, top: 8, bottom: 8, width: 3,
                background: k.tone === "danger" ? "var(--danger)" : k.tone === "accent" ? "var(--accent)" : "var(--gold)"
              }} />
              <small style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.07em", color: "var(--text-faint)" }}>{k.l}</small>
              <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: "-0.025em", marginTop: 2 }}>{k.v}</div>
              <small style={{ fontSize: 9.5, color: "var(--text-soft)" }}>{k.s}</small>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 4, borderBottom: "1px solid var(--border)", paddingTop: 4 }}>
        {["Today", "People", "Money", "Operations", "Insights"].map((t, i) => (
          <span key={t} style={{
            padding: "8px 12px", fontSize: 12, fontWeight: 600,
            color: i === 0 ? "var(--text)" : "var(--text-soft)",
            borderBottom: i === 0 ? "2px solid var(--brand)" : "2px solid transparent",
            display: "inline-flex", gap: 6
          }}>
            {t}
            {t === "People" && <span style={{ background: "var(--danger)", color: "white", fontSize: 9, padding: "1px 5px", borderRadius: 999, fontWeight: 800 }}>23</span>}
            {t === "Money" && <span style={{ background: "var(--danger)", color: "white", fontSize: 9, padding: "1px 5px", borderRadius: 999, fontWeight: 800 }}>7</span>}
          </span>
        ))}
      </div>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1.6fr 1fr" }}>
        <div className="flow-card">
          <div className="flow-card__head">
            <h3>
              <span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--brand)", display: "inline-block", marginRight: 6, verticalAlign: "middle" }} />
              Priorities
              <span className="flow-tag flow-tag--ok" style={{ marginLeft: 6 }}>12</span>
            </h3>
            <span className="flow-card__link">All actions →</span>
          </div>
          <div className="flow-card__body flow-card__body--flush">
            {[
              { tag: "EXPIRED", tone: "expired", who: "Rohan Mehta", what: "Annual Pro · lapsed 4 days ago", btn: "Renew" },
              { tag: "PAYMENT", tone: "payment", who: "Ananya Bose", what: "Half-year PT · ₹18,500 · Cash", btn: "Approve" },
              { tag: "EXPIRING", tone: "expiring", who: "Devansh Joshi", what: "Quarterly · expires in 5 days", btn: "Send" },
              { tag: "NO PLAN", tone: "noplan", who: "Pari Saxena", what: "Joined 11 days ago", btn: "Assign" },
              { tag: "NO PLAN", tone: "noplan", who: "Veer Tiwari", what: "Joined 8 days ago · build muscle", btn: "Assign" }
            ].map((r) => (
              <div key={r.who} className="flow-row" style={{ display: "grid", gridTemplateColumns: "70px 1fr auto", padding: "10px 14px" }}>
                <span className={`flow-tag flow-tag--${r.tone}`}>{r.tag}</span>
                <div>
                  <strong>{r.who}</strong>
                  <small>{r.what}</small>
                </div>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ fontSize: 10, padding: "4px 10px" }}>{r.btn}</button>
              </div>
            ))}
          </div>
        </div>

        <div className="flow-stack flow-stack--gap-12">
          <div className="flow-card">
            <div className="flow-card__head"><h3><window.MIcons.Calendar size={12} /> Today's PT</h3></div>
            <div className="flow-card__body flow-card__body--flush">
              {FO().ptSessions.slice(0, 4).map((s, i) => (
                <div key={i} className="flow-row" style={{ display: "grid", gridTemplateColumns: "40px 1fr auto", padding: "8px 14px" }}>
                  <strong style={{ fontSize: 11, fontVariantNumeric: "tabular-nums" }}>{s.time}</strong>
                  <div>
                    <strong style={{ fontSize: 11.5 }}>{s.member}</strong>
                    <small style={{ fontSize: 10 }}>{s.focus}</small>
                  </div>
                  <span className={`flow-tag flow-tag--${s.status === "completed" ? "neutral" : s.status === "in_progress" ? "ok" : "noplan"}`}>
                    {s.status === "completed" ? "DONE" : s.status === "in_progress" ? "LIVE" : "SOON"}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="flow-card">
            <div className="flow-card__head"><h3><window.MIcons.Activity size={12} /> Activity</h3></div>
            <div className="flow-card__body" style={{ paddingTop: 6, paddingBottom: 6 }}>
              {[
                { who: "Karthik Reddy", v: "joined the gym", at: "2h" },
                { who: "Aanya Sharma", v: "completed Push B", at: "4h" },
                { who: "Ishaan Kapoor", v: "hit a new bench PR", at: "5h" }
              ].map((n, i) => (
                <div key={i} style={{ padding: "6px 0", borderBottom: i < 2 ? "1px solid var(--border)" : "none", fontSize: 11.5 }}>
                  <strong>{n.who}</strong> {n.v}
                  <div style={{ fontSize: 10, color: "var(--text-faint)" }}>{n.at} ago</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerDashboard = FlowOwnerDashboard;

// ── 2. Members List ────────────────────────────────────────────────────
function FlowOwnerMembers() {
  return (
    <window.FlowOwnerChrome active="members" title="Members" crumb="Members" primaryAction="Add member">
      <div className="flow-grid-4">
        {[
          { l: "TOTAL", v: "247", s: "+6 this week", tone: "" },
          { l: "ACTIVE", v: "218", s: "88% of base", tone: "brand" },
          { l: "NEEDS PLAN", v: "23", s: "workout unassigned", tone: "warn" },
          { l: "RENEWALS DUE", v: "22", s: "4 already lapsed", tone: "danger" }
        ].map((k) => (
          <div key={k.l} className={`flow-kpi flow-kpi--${k.tone}`}>
            <small>{k.l}</small><strong>{k.v}</strong><em>{k.s}</em>
          </div>
        ))}
      </div>

      <div className="flow-card">
        <div className="flow-card__head" style={{ gap: 10 }}>
          <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, background: "var(--bg-subtle)", borderRadius: 8, padding: "5px 10px", maxWidth: 300 }}>
            <window.MIcons.Search size={13} />
            <span style={{ fontSize: 12, color: "var(--text-soft)" }}>Search name or @username</span>
          </div>
          <span style={{ fontSize: 11, color: "var(--text-soft)" }}>247 members</span>
          <span style={{ background: "var(--bg-subtle)", color: "var(--text)", padding: "5px 10px", borderRadius: 8, fontSize: 11, fontWeight: 600 }}>
            Sort · Name (A–Z)
          </span>
        </div>
        <div className="flow-card__body flow-card__body--flush">
          <div style={{
            display: "grid", gridTemplateColumns: "24px minmax(0,1.6fr) 1.2fr 1fr 80px 30px",
            padding: "8px 14px", background: "var(--bg-subtle)", borderBottom: "1px solid var(--border)",
            fontSize: 9.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.07em", color: "var(--text-faint)", gap: 12
          }}>
            <span></span><span>MEMBER</span><span>MEMBERSHIP</span><span>WORKOUT PLAN</span><span>JOINED</span><span></span>
          </div>
          {FO().members.slice(0, 6).map((m, i) => (
            <div key={m.name} style={{
              display: "grid", gridTemplateColumns: "24px minmax(0,1.6fr) 1.2fr 1fr 80px 30px",
              padding: "10px 14px", borderBottom: "1px solid var(--border)",
              alignItems: "center", gap: 12
            }}>
              <input type="checkbox" disabled style={{ width: 14, height: 14 }} />
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span className={`fm-avatar fm-avatar--sm fs-avatar--c${(i % 6) + 1}`}>{m.name.split(" ").map(x => x[0]).slice(0, 2).join("")}</span>
                <div>
                  <strong style={{ fontSize: 12.5 }}>{m.name}</strong>
                  <div style={{ fontSize: 10.5, color: "var(--text-soft)" }}>@{m.handle}</div>
                </div>
              </div>
              <div>
                <span className={`flow-tag flow-tag--${m.state === "ok" ? "ok" : m.state}`}>
                  {m.state === "ok" ? "ACTIVE" : m.state === "expired" ? "EXPIRED" : m.state === "noplan" ? "ACTIVE" : m.state === "expiring" ? "EXPIRING" : m.state === "payment" ? "PAYMENT" : "ACTIVE"}
                </span>
                <div style={{ fontSize: 10, color: "var(--text-soft)", marginTop: 2 }}>{m.expiry} · {m.plan}</div>
              </div>
              <div>
                {m.trainer ? (
                  <>
                    <span style={{ background: "var(--bg-subtle)", padding: "2px 8px", borderRadius: 999, fontSize: 10.5, fontWeight: 600 }}>
                      Hypertrophy 12wk
                    </span>
                    <div style={{ fontSize: 10, color: "var(--text-soft)", marginTop: 2 }}>w/ {m.trainer}</div>
                  </>
                ) : (
                  <span className="flow-tag flow-tag--neutral" style={{ background: "transparent", border: "1px solid var(--border)" }}>No plan</span>
                )}
              </div>
              <div style={{ fontSize: 11, color: "var(--text-soft)" }}>{["12 Mar", "8 Jan", "22 Feb", "1 Apr", "15 Mar", "3 May"][i]}</div>
              <window.MIcons.More size={13} />
            </div>
          ))}
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerMembers = FlowOwnerMembers;

// ── 3. Member Detail ──────────────────────────────────────────────────
function FlowOwnerMemberDetail() {
  return (
    <window.FlowOwnerChrome active="members" title="Aanya Sharma" crumb="Members / Aanya Sharma" primaryAction="Edit member">
      <div className="flow-card">
        <div className="flow-card__body" style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 18, alignItems: "center" }}>
          <span className="fm-avatar fm-avatar--xl fs-avatar--c1">AS</span>
          <div>
            <h2 className="flow-h2" style={{ fontSize: 22 }}>Aanya Sharma</h2>
            <p className="flow-page-desc">@aanya.s · +91 98765 12345 · joined 12 Mar 2024 · 14 sessions w/ Priya Nair</p>
            <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
              <span className="flow-tag flow-tag--ok">ACTIVE</span>
              <span className="flow-tag flow-tag--neutral">ANNUAL PRO · renews 12 Aug</span>
              <span className="flow-tag flow-tag--neutral">Hypertrophy 12wk · wk 4</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <button className="flow-pill-btn flow-pill-btn--ghost">Message</button>
            <button className="flow-pill-btn flow-pill-btn--ghost">Reassign trainer</button>
            <button className="flow-pill-btn">Renew</button>
          </div>
        </div>
      </div>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1.6fr 1fr" }}>
        <div className="flow-stack flow-stack--gap-12">
          <div className="flow-grid-3">
            <div className="flow-kpi flow-kpi--brand"><small>STREAK</small><strong>7w</strong><em>weekly</em></div>
            <div className="flow-kpi"><small>THIS MONTH</small><strong>14</strong><em>workouts</em></div>
            <div className="flow-kpi flow-kpi--accent"><small>BENCH PR</small><strong>52.5kg</strong><em>+5kg in 8w</em></div>
          </div>

          <div className="flow-card">
            <div className="flow-card__head"><h3>Recent activity</h3></div>
            <div className="flow-card__body flow-card__body--flush">
              {[
                { d: "Today", w: "Day B · Push", t: "Completed · 55m" },
                { d: "Yesterday", w: "Day A · Pull", t: "Completed · 52m" },
                { d: "26 May", w: "Day C · Legs", t: "Completed · 60m" },
                { d: "24 May", w: "PT session", t: "Bench technique · Priya N." }
              ].map((a, i) => (
                <div key={i} className="flow-row" style={{ display: "grid", gridTemplateColumns: "70px 1fr auto", padding: "8px 14px" }}>
                  <strong style={{ fontSize: 11 }}>{a.d}</strong>
                  <div>
                    <strong style={{ fontSize: 11.5 }}>{a.w}</strong>
                    <small style={{ fontSize: 10.5 }}>{a.t}</small>
                  </div>
                  <span className="flow-tag flow-tag--ok">DONE</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="flow-stack flow-stack--gap-12">
          <div className="flow-card">
            <div className="flow-card__head"><h3>Membership</h3></div>
            <div className="flow-card__body">
              <div style={{ fontSize: 18, fontWeight: 700, letterSpacing: "-0.025em" }}>Annual Pro</div>
              <div style={{ fontSize: 11, color: "var(--text-soft)", marginBottom: 8 }}>Renews 12 Aug 2026 · 76 days</div>
              <div style={{ height: 5, background: "var(--bg-subtle)", borderRadius: 999, overflow: "hidden", marginBottom: 10 }}>
                <div style={{ width: "20%", height: "100%", background: "var(--brand)" }} />
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ flex: 1, fontSize: 11, padding: "5px" }}>Pause</button>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ flex: 1, fontSize: 11, padding: "5px", color: "var(--danger)", borderColor: "color-mix(in srgb, var(--danger) 30%, transparent)" }}>Suspend</button>
              </div>
            </div>
          </div>
          <div className="flow-card">
            <div className="flow-card__head"><h3>Body metrics</h3></div>
            <div className="flow-card__body" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
              <div style={{ background: "var(--bg-subtle)", borderRadius: 8, padding: 8 }}>
                <small style={{ fontSize: 9.5, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase" }}>WEIGHT</small>
                <div style={{ fontSize: 16, fontWeight: 700 }}>56.2<small style={{ fontSize: 10, color: "var(--text-soft)" }}>kg</small></div>
              </div>
              <div style={{ background: "var(--bg-subtle)", borderRadius: 8, padding: 8 }}>
                <small style={{ fontSize: 9.5, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase" }}>BMI</small>
                <div style={{ fontSize: 16, fontWeight: 700 }}>20.6</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerMemberDetail = FlowOwnerMemberDetail;

// ── 4. Programs Library ───────────────────────────────────────────────
function FlowOwnerPrograms() {
  return (
    <window.FlowOwnerChrome active="programs" title="Workout programs" crumb="Programs" primaryAction="Build program">
      <div className="flow-grid-3">
        <div className="flow-kpi flow-kpi--brand"><small>TOTAL PROGRAMS</small><strong>16</strong><em>6 gym-built · 10 presets</em></div>
        <div className="flow-kpi flow-kpi--accent"><small>ACTIVE ASSIGNMENTS</small><strong>184</strong><em>across members</em></div>
        <div className="flow-kpi"><small>MOST USED</small><strong>Hypertrophy 12wk</strong><em>18 members</em></div>
      </div>

      <div style={{ display: "flex", gap: 6 }}>
        {["All 16", "Gym-built 6", "Preset 10", "Recently used"].map((c, i) => (
          <span key={c} style={{
            background: i === 0 ? "var(--text)" : "var(--bg-elevated)",
            color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
            border: i === 0 ? "none" : "1px solid var(--border)",
            padding: "5px 11px", borderRadius: 999, fontSize: 11.5, fontWeight: 600
          }}>{c}</span>
        ))}
      </div>

      <div className="flow-grid-3">
        {FO().programs.map((p, i) => (
          <div key={p.title} className="flow-card" style={{ padding: 0 }}>
            <div style={{
              height: 60,
              background: `linear-gradient(135deg, ${["var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)", "var(--brand)", "var(--accent)"][i]}, color-mix(in srgb, ${["var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)", "var(--brand)", "var(--accent)"][i]} 50%, transparent))`,
              padding: 10, color: "white", position: "relative"
            }}>
              <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: "0.08em", background: "rgba(255,255,255,0.18)", padding: "2px 7px", borderRadius: 999 }}>
                {p.source === "gym" ? "GYM-BUILT" : "PRESET"}
              </span>
              <div style={{ position: "absolute", bottom: 8, left: 10, fontWeight: 700, fontSize: 13, letterSpacing: "-0.01em" }}>{p.title}</div>
            </div>
            <div style={{ padding: "10px 12px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10.5, color: "var(--text-soft)" }}>
                <span>{p.level} · {p.duration}</span>
                <span><strong style={{ color: "var(--text)" }}>{p.assigned}</strong> assigned</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerPrograms = FlowOwnerPrograms;

// ── 5. Packages ───────────────────────────────────────────────────────
function FlowOwnerPackages() {
  return (
    <window.FlowOwnerChrome active="packages" title="Membership packages" crumb="Packages" primaryAction="New package">
      <p className="flow-page-desc">
        Define the membership plans your gym offers. Members can request a package and you approve the payment.
      </p>

      <div className="flow-grid-3">
        {FO().packages.map((p, i) => (
          <div key={p.name} className="flow-card">
            <div className="flow-card__body">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                <div>
                  <span className="flow-eyebrow">{p.months >= 12 ? "ANNUAL" : p.months >= 6 ? "HALF-YEAR" : p.months >= 3 ? "QUARTERLY" : "MONTHLY"}</span>
                  <h3 style={{ fontSize: 15, fontWeight: 700, margin: "2px 0 0", letterSpacing: "-0.015em" }}>{p.name}</h3>
                </div>
                <span className="flow-tag flow-tag--ok">ACTIVE</span>
              </div>
              <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: "-0.03em", margin: "4px 0" }}>
                ₹{p.price.toLocaleString("en-IN")}
                <small style={{ fontSize: 11, color: "var(--text-soft)", fontWeight: 500, marginLeft: 4 }}>/ {p.months} mo</small>
              </div>
              <div style={{ fontSize: 11, color: "var(--text-soft)", marginBottom: 12 }}>
                <strong style={{ color: "var(--text)" }}>{p.members}</strong> members on this plan
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ flex: 1, fontSize: 11, padding: "5px" }}>Edit</button>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ flex: 1, fontSize: 11, padding: "5px" }}>Deactivate</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerPackages = FlowOwnerPackages;

// ── 6. Exercises ──────────────────────────────────────────────────────
function FlowOwnerExercises() {
  return (
    <window.FlowOwnerChrome active="exercises" title="Exercise catalog" crumb="Exercises" primaryAction="New exercise">
      <p className="flow-page-desc">
        Reusable exercises across all programs. Tag by muscle group, equipment, and add demo videos.
      </p>

      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <div style={{ flex: 1, maxWidth: 280, background: "var(--bg-subtle)", borderRadius: 8, padding: "6px 10px", display: "flex", alignItems: "center", gap: 8 }}>
          <window.MIcons.Search size={13} />
          <span style={{ fontSize: 12, color: "var(--text-soft)" }}>Search exercises…</span>
        </div>
        {["All", "Chest", "Back", "Legs", "Shoulders", "Arms"].map((c, i) => (
          <span key={c} style={{
            background: i === 0 ? "var(--text)" : "var(--bg-subtle)",
            color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
            padding: "5px 11px", borderRadius: 999, fontSize: 11, fontWeight: 600
          }}>{c}</span>
        ))}
      </div>

      <div className="flow-card">
        <div className="flow-card__body flow-card__body--flush">
          {FO().exercises.map((ex, i) => (
            <div key={ex.name} style={{
              display: "grid", gridTemplateColumns: "36px 1.6fr 1fr 1fr 80px 30px",
              padding: "10px 14px", borderBottom: i < FO().exercises.length - 1 ? "1px solid var(--border)" : "none",
              alignItems: "center", gap: 14
            }}>
              <div style={{
                width: 30, height: 30, borderRadius: 8, background: "var(--bg-subtle)",
                display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-soft)"
              }}>
                <window.MIcons.Dumbbell size={14} />
              </div>
              <div>
                <strong style={{ fontSize: 13 }}>{ex.name}</strong>
                <div style={{ fontSize: 10.5, color: "var(--text-soft)" }}>Demo video uploaded</div>
              </div>
              <span style={{ fontSize: 11.5 }}>{ex.group}</span>
              <span style={{ fontSize: 11.5, color: "var(--text-soft)" }}>{ex.equipment}</span>
              <span style={{ fontSize: 11, color: "var(--text-soft)" }}>used in {[8, 5, 7, 6, 4, 9][i]} programs</span>
              <window.MIcons.More size={13} />
            </div>
          ))}
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerExercises = FlowOwnerExercises;
