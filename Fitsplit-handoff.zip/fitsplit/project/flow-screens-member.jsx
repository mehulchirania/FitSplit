// E2E Flow — Member screens (mobile, coach-led direction)

const { useState: useStateM } = React;
const FM = () => window.FLOW_MOCK;

function FlowAvatar({ initials, size = "md", color = 1 }) {
  return <span className={`fm-avatar fm-avatar--${size} fs-avatar--c${color}`}>{initials}</span>;
}

// ── Member Dashboard (coach-led mobile) ─────────────────────────────────
function FlowMemberDashboard() {
  const m = FM().member;
  return (
    <window.FlowMobileChrome activeTab="home">
      <div className="flow-mobile__topbar">
        <div>
          <span className="flow-eyebrow" style={{ marginBottom: 0 }}>TITAN STRENGTH</span>
          <div className="flow-mobile__greet">Hi, {m.firstName} 👋</div>
        </div>
        <FlowAvatar initials={m.initials} size="sm" color={m.avatarColor} />
      </div>

      {/* Coach hero */}
      <div style={{
        background: "linear-gradient(140deg, color-mix(in srgb, var(--brand) 14%, var(--bg-elevated)), var(--bg-elevated))",
        border: "1px solid color-mix(in srgb, var(--brand) 22%, var(--border))",
        borderRadius: 16, padding: 14, marginBottom: 12, position: "relative", overflow: "hidden"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <FlowAvatar initials="PN" size="md" />
          <div>
            <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: "0.1em", color: "var(--text-faint)" }}>YOUR COACH</span>
            <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: "-0.01em" }}>Priya Nair</div>
          </div>
        </div>
        <div style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: "12px 12px 12px 4px", padding: "10px 12px", marginLeft: 4, marginBottom: 10
        }}>
          <p style={{ margin: 0, fontSize: 12.5, lineHeight: 1.4 }}>
            Aanya — slight pause at the bottom of every bench rep today. Don't bounce. Form > reps. 💪
          </p>
        </div>
        <div style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: 12, padding: "6px 10px", display: "flex", alignItems: "center", gap: 6
        }}>
          <span style={{ fontSize: 12, color: "var(--text-faint)", flex: 1 }}>Reply to Coach…</span>
          <span style={{
            background: "var(--brand-soft)", color: "var(--brand)",
            padding: "3px 8px", borderRadius: 999, fontSize: 10, fontWeight: 600
          }}>Got it 👍</span>
          <span style={{
            width: 24, height: 24, borderRadius: "50%", background: "var(--brand)",
            color: "white", display: "flex", alignItems: "center", justifyContent: "center"
          }}>
            <window.MIcons.Send size={11} />
          </span>
        </div>
      </div>

      {/* Today's plan */}
      <div style={{ background: "var(--bg-elevated)", border: "1px solid var(--border)", borderRadius: 14, padding: 14, marginBottom: 12 }}>
        <span className="flow-eyebrow" style={{ color: "var(--brand)" }}>
          <window.MIcons.Note size={10} /> COACH'S PLAN FOR TODAY
        </span>
        <h3 style={{ fontSize: 18, fontWeight: 700, margin: "4px 0 4px", letterSpacing: "-0.025em" }}>Day B · Push</h3>
        <span style={{ fontSize: 11, color: "var(--text-soft)" }}>Week 4 · 6 lifts · ~55m</span>

        <div style={{ marginTop: 10, marginBottom: 12 }}>
          {[
            { n: "Bench Press", m: "4×5–8 · last 50kg" },
            { n: "Incline DB Press", m: "3×8–10 · last 16kg" },
            { n: "Overhead Press", m: "3×6–8 · ↑ try 27.5kg" }
          ].map((e, i) => (
            <div key={i} style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "8px 10px", borderRadius: 10, background: "var(--bg-subtle)", marginBottom: 4
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 7, background: "var(--bg-elevated)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 11, fontWeight: 700, color: "var(--text-soft)"
              }}>{i + 1}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12.5, fontWeight: 700 }}>{e.n}</div>
                <small style={{ fontSize: 10.5, color: "var(--text-soft)" }}>{e.m}</small>
              </div>
            </div>
          ))}
          <div style={{ textAlign: "center", color: "var(--text-faint)", fontSize: 11, padding: 4 }}>+ 3 more lifts</div>
        </div>

        <button style={{
          width: "100%", background: "var(--brand)", color: "white",
          border: "none", borderRadius: 12, padding: 12,
          fontSize: 13, fontWeight: 700, cursor: "pointer", display: "flex",
          alignItems: "center", justifyContent: "center", gap: 6
        }}>
          <window.MIcons.Play size={13} /> Start workout
        </button>
      </div>

      {/* Stats grid */}
      <div style={{
        background: "var(--bg-elevated)", border: "1px solid var(--border)", borderRadius: 12,
        padding: 12, marginBottom: 12
      }}>
        <span className="flow-eyebrow">YOUR PROGRESS</span>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginTop: 8 }}>
          {[
            { v: `${m.streak}w`, l: "streak", c: "#e8c374" },
            { v: `${m.daysThisWeek}/${m.target}`, l: "this week", c: "var(--brand)" },
            { v: `${m.bench}kg`, l: "bench PR", c: "var(--accent)" },
            { v: "56.2kg", l: "body wt.", c: "var(--danger)" }
          ].map((s) => (
            <div key={s.l} style={{
              background: "var(--bg-subtle)", borderRadius: 10, padding: "8px 4px", textAlign: "center"
            }}>
              <div style={{ color: s.c, fontSize: 13, marginBottom: 2 }}>●</div>
              <strong style={{ fontSize: 14, fontWeight: 700, letterSpacing: "-0.02em" }}>{s.v}</strong>
              <div style={{ fontSize: 8.5, color: "var(--text-faint)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.07em" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming PT */}
      <div style={{
        background: "var(--bg-elevated)", border: "1px solid var(--border)", borderRadius: 12,
        padding: 12, display: "flex", alignItems: "center", gap: 10
      }}>
        <div style={{ width: 32, height: 32, borderRadius: 9, background: "var(--accent-soft)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <window.MIcons.Calendar size={14} />
        </div>
        <div style={{ flex: 1 }}>
          <span className="flow-eyebrow" style={{ marginBottom: 0 }}>UPCOMING PT</span>
          <div style={{ fontSize: 12.5, fontWeight: 700 }}>Tomorrow, 6:30 AM</div>
          <small style={{ fontSize: 10.5, color: "var(--text-soft)" }}>Bench technique · 45m</small>
        </div>
        <window.MIcons.ChevR size={14} />
      </div>
    </window.FlowMobileChrome>
  );
}
window.FlowMemberDashboard = FlowMemberDashboard;

// ── Member Programs Library ─────────────────────────────────────────────
function FlowMemberPrograms() {
  return (
    <window.FlowMobileChrome activeTab="train">
      <div className="flow-mobile__topbar">
        <div>
          <span className="flow-eyebrow" style={{ marginBottom: 0 }}>WORKOUT LIBRARY</span>
          <div className="flow-mobile__greet" style={{ fontSize: 17 }}>Programs</div>
        </div>
        <span style={{
          width: 32, height: 32, borderRadius: "50%", background: "var(--bg-subtle)",
          display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-soft)"
        }}>
          <window.MIcons.Search size={14} />
        </span>
      </div>

      {/* Filter chips */}
      <div style={{ display: "flex", gap: 6, marginBottom: 12, overflowX: "auto" }}>
        {["All", "Strength", "Hypertrophy", "Cardio", "Beginner"].map((c, i) => (
          <span key={c} style={{
            background: i === 0 ? "var(--text)" : "var(--bg-subtle)",
            color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
            padding: "5px 12px", borderRadius: 999, fontSize: 11.5, fontWeight: 600,
            flexShrink: 0
          }}>{c}</span>
        ))}
      </div>

      {/* Current program */}
      <div style={{
        background: "color-mix(in srgb, var(--brand) 10%, var(--bg-elevated))",
        border: "1px solid color-mix(in srgb, var(--brand) 28%, var(--border))",
        borderRadius: 14, padding: 14, marginBottom: 14
      }}>
        <span className="flow-eyebrow" style={{ color: "var(--brand)" }}>YOUR CURRENT PROGRAM</span>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
          <div>
            <strong style={{ fontSize: 16, letterSpacing: "-0.02em", fontWeight: 700 }}>Hypertrophy 12wk</strong>
            <div style={{ fontSize: 11, color: "var(--text-soft)" }}>Week 4 of 12 · 4 day split</div>
          </div>
          <div style={{
            background: "var(--brand)", color: "white", borderRadius: 999,
            padding: "4px 10px", fontSize: 11, fontWeight: 700, height: "fit-content"
          }}>ACTIVE</div>
        </div>
      </div>

      {/* Library list */}
      <span className="flow-eyebrow">BROWSE PROGRAMS</span>
      {FM().programs.map((p) => (
        <div key={p.title} style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: 12, padding: 12, marginTop: 6,
          display: "flex", justifyContent: "space-between", alignItems: "center"
        }}>
          <div>
            <strong style={{ fontSize: 13.5, fontWeight: 700, letterSpacing: "-0.01em" }}>{p.title}</strong>
            <div style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 1 }}>
              {p.level} · {p.duration}
            </div>
          </div>
          <window.MIcons.ChevR size={14} />
        </div>
      ))}
    </window.FlowMobileChrome>
  );
}
window.FlowMemberPrograms = FlowMemberPrograms;

// ── Program Detail ──────────────────────────────────────────────────────
function FlowMemberProgramDetail() {
  return (
    <window.FlowMobileChrome activeTab="train">
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <window.MIcons.ChevL size={18} />
        <span style={{ fontSize: 11, color: "var(--text-soft)" }}>Programs</span>
      </div>

      <span className="flow-eyebrow" style={{ color: "var(--brand)" }}>ACTIVE PROGRAM</span>
      <h2 style={{ fontSize: 24, fontWeight: 700, margin: "4px 0 4px", letterSpacing: "-0.025em" }}>Hypertrophy 12wk</h2>
      <p style={{ fontSize: 12, color: "var(--text-soft)", margin: "0 0 14px" }}>
        Intermediate · 4 day split · designed for muscle growth across 12 weeks.
      </p>

      {/* Progress */}
      <div style={{
        background: "var(--bg-elevated)", border: "1px solid var(--border)", borderRadius: 12,
        padding: 12, marginBottom: 12
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: "var(--text-faint)", textTransform: "uppercase", letterSpacing: "0.07em" }}>PROGRESS</span>
          <span style={{ fontSize: 12, fontWeight: 700 }}>Week 4 of 12</span>
        </div>
        <div style={{ height: 6, background: "var(--bg-subtle)", borderRadius: 999, overflow: "hidden" }}>
          <div style={{ height: "100%", width: "33%", background: "var(--brand)", borderRadius: 999 }} />
        </div>
      </div>

      <span className="flow-eyebrow">WEEK SCHEDULE</span>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4, marginBottom: 14 }}>
        {[
          { d: "M", l: "Pull A" }, { d: "T", l: "Push B" }, { d: "W", l: "" },
          { d: "T", l: "Legs A" }, { d: "F", l: "Push B", today: true },
          { d: "S", l: "Pull B" }, { d: "S", l: "" }
        ].map((day, i) => (
          <div key={i} style={{
            background: day.today ? "var(--brand)" : day.l ? "var(--brand-soft)" : "var(--bg-subtle)",
            color: day.today ? "white" : "var(--text)",
            borderRadius: 8, padding: "8px 2px", textAlign: "center"
          }}>
            <div style={{ fontSize: 9, fontWeight: 700, opacity: 0.7 }}>{day.d}</div>
            <div style={{ fontSize: 10, fontWeight: 700, marginTop: 2 }}>{day.l || "—"}</div>
          </div>
        ))}
      </div>

      <span className="flow-eyebrow">DAY B · PUSH</span>
      {FM().todayExercises.slice(0, 4).map((ex, i) => (
        <div key={i} style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: 10, padding: 10, marginTop: 6
        }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <strong style={{ fontSize: 13, fontWeight: 700 }}>{ex.name}</strong>
            <span style={{ fontSize: 11, color: "var(--text-soft)" }}>{ex.sets}×{ex.reps}</span>
          </div>
          <div style={{ fontSize: 10.5, color: "var(--text-faint)", marginTop: 2 }}>{ex.group} · target {ex.target}kg</div>
        </div>
      ))}
    </window.FlowMobileChrome>
  );
}
window.FlowMemberProgramDetail = FlowMemberProgramDetail;

// ── Membership ─────────────────────────────────────────────────────────
function FlowMemberMembership() {
  const m = FM().member;
  return (
    <window.FlowMobileChrome activeTab="profile">
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <window.MIcons.ChevL size={18} />
        <span style={{ fontSize: 11, color: "var(--text-soft)" }}>Profile</span>
      </div>
      <span className="flow-eyebrow">YOUR MEMBERSHIP</span>
      <h2 style={{ fontSize: 22, fontWeight: 700, margin: "4px 0 14px", letterSpacing: "-0.025em" }}>Annual Pro</h2>

      <div style={{
        background: "linear-gradient(140deg, color-mix(in srgb, var(--brand) 20%, var(--bg-elevated)), var(--bg-elevated))",
        border: "1px solid color-mix(in srgb, var(--brand) 30%, var(--border))",
        borderRadius: 16, padding: 18, marginBottom: 14
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
          <span style={{ fontSize: 10, fontWeight: 800, color: "var(--brand)", letterSpacing: "0.1em" }}>MEMBERSHIP CARD</span>
          <span style={{ background: "var(--brand)", color: "white", padding: "3px 8px", borderRadius: 999, fontSize: 10, fontWeight: 700 }}>ACTIVE</span>
        </div>
        <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: "-0.025em", marginBottom: 2 }}>{m.firstName} {m.lastName}</div>
        <div style={{ fontSize: 11, color: "var(--text-soft)" }}>@{m.handle} · Titan Strength · Bandra</div>
        <div style={{
          display: "flex", justifyContent: "space-between",
          marginTop: 16, paddingTop: 12, borderTop: "1px solid var(--border)"
        }}>
          <div>
            <small style={{ fontSize: 9.5, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase" }}>PLAN</small>
            <div style={{ fontSize: 13, fontWeight: 700 }}>Annual Pro</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <small style={{ fontSize: 9.5, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase" }}>RENEWS</small>
            <div style={{ fontSize: 13, fontWeight: 700 }}>{m.membership.expiry}</div>
          </div>
        </div>
      </div>

      <div style={{
        background: "var(--bg-elevated)", border: "1px solid var(--border)",
        borderRadius: 12, padding: 12, marginBottom: 8
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
          <span style={{ fontSize: 11.5, fontWeight: 600 }}>Days remaining</span>
          <strong style={{ fontSize: 13, fontWeight: 700 }}>{m.membership.daysLeft} days</strong>
        </div>
        <div style={{ height: 5, background: "var(--bg-subtle)", borderRadius: 999, overflow: "hidden" }}>
          <div style={{ height: "100%", width: "20%", background: "var(--brand)", borderRadius: 999 }} />
        </div>
      </div>

      <span className="flow-eyebrow" style={{ marginTop: 8 }}>PAYMENT HISTORY</span>
      {[
        { date: "12 Aug 2025", amount: 14999, mode: "UPI", status: "paid" },
        { date: "12 Aug 2024", amount: 12999, mode: "Card", status: "paid" }
      ].map((p, i) => (
        <div key={i} style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: 10, padding: 10, marginTop: 6,
          display: "flex", justifyContent: "space-between", alignItems: "center"
        }}>
          <div>
            <strong style={{ fontSize: 13, fontWeight: 700 }}>₹{p.amount.toLocaleString("en-IN")}</strong>
            <div style={{ fontSize: 10.5, color: "var(--text-soft)" }}>{p.date} · {p.mode}</div>
          </div>
          <span className="flow-tag flow-tag--ok">PAID</span>
        </div>
      ))}
    </window.FlowMobileChrome>
  );
}
window.FlowMemberMembership = FlowMemberMembership;

// ── PT History ─────────────────────────────────────────────────────────
function FlowMemberPTHistory() {
  return (
    <window.FlowMobileChrome activeTab="progress">
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <window.MIcons.ChevL size={18} />
        <span style={{ fontSize: 11, color: "var(--text-soft)" }}>Progress</span>
      </div>
      <span className="flow-eyebrow">PERSONAL TRAINING</span>
      <h2 style={{ fontSize: 22, fontWeight: 700, margin: "4px 0 4px", letterSpacing: "-0.025em" }}>PT history</h2>
      <p style={{ fontSize: 11.5, color: "var(--text-soft)", margin: "0 0 14px" }}>
        14 sessions with Priya · 4 with Vikram
      </p>

      {/* Upcoming */}
      <div style={{
        background: "color-mix(in srgb, var(--accent) 10%, var(--bg-elevated))",
        border: "1px solid color-mix(in srgb, var(--accent) 24%, var(--border))",
        borderRadius: 12, padding: 12, marginBottom: 14
      }}>
        <span className="flow-eyebrow" style={{ color: "var(--accent)" }}>UPCOMING</span>
        <div style={{ fontWeight: 700, fontSize: 14, marginTop: 4 }}>Tomorrow · 6:30 AM</div>
        <div style={{ fontSize: 11, color: "var(--text-soft)" }}>Bench technique · 45m · Priya N.</div>
      </div>

      <span className="flow-eyebrow">PAST SESSIONS</span>
      {FM().ptHistory.filter(s => s.status === "completed").map((s, i) => (
        <div key={i} style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: 10, padding: 12, marginTop: 6
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <strong style={{ fontSize: 12.5, fontWeight: 700 }}>{s.focus}</strong>
              <div style={{ fontSize: 10.5, color: "var(--text-soft)", marginTop: 2 }}>{s.date} · {s.trainer} · {s.duration}m</div>
            </div>
            <span className="flow-tag flow-tag--ok">DONE</span>
          </div>
        </div>
      ))}
    </window.FlowMobileChrome>
  );
}
window.FlowMemberPTHistory = FlowMemberPTHistory;

// ── Profile ────────────────────────────────────────────────────────────
function FlowMemberProfile() {
  const m = FM().member;
  return (
    <window.FlowMobileChrome activeTab="profile">
      <div style={{ textAlign: "center", padding: "8px 0 18px" }}>
        <FlowAvatar initials={m.initials} size="xl" color={m.avatarColor} />
        <h2 style={{ fontSize: 20, fontWeight: 700, margin: "10px 0 2px", letterSpacing: "-0.025em" }}>{m.firstName} {m.lastName}</h2>
        <div style={{ fontSize: 11.5, color: "var(--text-soft)" }}>@{m.handle} · {m.mobile}</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 14 }}>
        {[
          { l: "GOAL", v: m.goal },
          { l: "LEVEL", v: m.level },
          { l: "STREAK", v: `${m.streak} weeks` },
          { l: "SINCE", v: "Mar 2024" }
        ].map((s) => (
          <div key={s.l} style={{
            background: "var(--bg-elevated)", border: "1px solid var(--border)",
            borderRadius: 10, padding: 10
          }}>
            <small style={{ fontSize: 9.5, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.07em" }}>{s.l}</small>
            <div style={{ fontSize: 13, fontWeight: 700, marginTop: 1 }}>{s.v}</div>
          </div>
        ))}
      </div>

      <span className="flow-eyebrow">QUICK ACCESS</span>
      <div className="flow-stack" style={{ marginTop: 6 }}>
        {[
          { l: "Membership", s: "Active · renews 12 Aug", i: <window.MIcons.Heart size={14} /> },
          { l: "PT history", s: "14 completed sessions", i: <window.MIcons.Calendar size={14} /> },
          { l: "Body metrics", s: "56.2kg · last logged today", i: <window.MIcons.Activity size={14} /> },
          { l: "Notifications", s: "3 unread", i: <window.MIcons.Bell size={14} /> }
        ].map((it) => (
          <div key={it.l} style={{
            background: "var(--bg-elevated)", border: "1px solid var(--border)",
            borderRadius: 10, padding: 12, display: "flex", alignItems: "center", gap: 10
          }}>
            <div style={{
              width: 30, height: 30, borderRadius: 9, background: "var(--bg-subtle)",
              display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-soft)"
            }}>{it.i}</div>
            <div style={{ flex: 1 }}>
              <strong style={{ fontSize: 12.5, fontWeight: 700 }}>{it.l}</strong>
              <div style={{ fontSize: 10.5, color: "var(--text-soft)" }}>{it.s}</div>
            </div>
            <window.MIcons.ChevR size={14} />
          </div>
        ))}
      </div>
    </window.FlowMobileChrome>
  );
}
window.FlowMemberProfile = FlowMemberProfile;

// ── Exercise Library (member) ───────────────────────────────────────────
function FlowMemberExercises() {
  return (
    <window.FlowMobileChrome activeTab="train">
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <window.MIcons.ChevL size={18} />
        <span style={{ fontSize: 11, color: "var(--text-soft)" }}>Programs</span>
      </div>
      <span className="flow-eyebrow">EXERCISE LIBRARY</span>
      <h2 style={{ fontSize: 22, fontWeight: 700, margin: "4px 0 12px", letterSpacing: "-0.025em" }}>Exercises</h2>

      <div style={{
        background: "var(--bg-subtle)", borderRadius: 10, padding: "8px 12px",
        display: "flex", alignItems: "center", gap: 8, marginBottom: 12
      }}>
        <window.MIcons.Search size={14} />
        <span style={{ fontSize: 12, color: "var(--text-soft)" }}>Search exercises…</span>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 12, overflowX: "auto" }}>
        {["All", "Chest", "Back", "Legs", "Shoulders"].map((c, i) => (
          <span key={c} style={{
            background: i === 0 ? "var(--text)" : "var(--bg-subtle)",
            color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
            padding: "5px 11px", borderRadius: 999, fontSize: 11, fontWeight: 600, flexShrink: 0
          }}>{c}</span>
        ))}
      </div>

      {FM().exercises.map((ex) => (
        <div key={ex.name} style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: 10, padding: 12, marginBottom: 6,
          display: "flex", alignItems: "center", gap: 10
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 8, background: "var(--bg-subtle)",
            display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-soft)"
          }}>
            <window.MIcons.Dumbbell size={15} />
          </div>
          <div style={{ flex: 1 }}>
            <strong style={{ fontSize: 13, fontWeight: 700 }}>{ex.name}</strong>
            <div style={{ fontSize: 10.5, color: "var(--text-soft)" }}>{ex.group} · {ex.equipment}</div>
          </div>
          <window.MIcons.ChevR size={14} />
        </div>
      ))}
    </window.FlowMobileChrome>
  );
}
window.FlowMemberExercises = FlowMemberExercises;
