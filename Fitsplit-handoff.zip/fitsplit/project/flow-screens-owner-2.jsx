// E2E Flow — Owner screens part 2: Billing, Trainers, Training/PT, Reports, Notifications, Settings

const FO2 = () => window.FLOW_MOCK;

// ── 7. Billing ───────────────────────────────────────────────────────
function FlowOwnerBilling() {
  const pending = FO2().payments.filter(p => p.status === "pending");
  return (
    <window.FlowOwnerChrome active="billing" title="Billing & payments" crumb="Billing" primaryAction="Request payment">
      <div className="flow-grid-4">
        <div className="flow-kpi flow-kpi--brand"><small>REVENUE MTD</small><strong>₹4.3<small style={{ fontSize: 11 }}>L</small></strong><em>+11% vs Apr</em></div>
        <div className="flow-kpi flow-kpi--warn"><small>PENDING APPROVAL</small><strong>{pending.length}</strong><em>₹{pending.reduce((s, p) => s + p.amount, 0).toLocaleString("en-IN")}</em></div>
        <div className="flow-kpi"><small>COLLECTED THIS WEEK</small><strong>₹89k</strong><em>22 payments</em></div>
        <div className="flow-kpi flow-kpi--danger"><small>OVERDUE</small><strong>4</strong><em>renewals lapsed</em></div>
      </div>

      <div style={{ display: "flex", gap: 4 }}>
        {["All", "Pending", "Approved", "Rejected"].map((c, i) => (
          <span key={c} style={{
            background: i === 1 ? "var(--text)" : "transparent",
            color: i === 1 ? "var(--bg-elevated)" : "var(--text-soft)",
            border: i === 1 ? "none" : "1px solid var(--border)",
            padding: "5px 12px", borderRadius: 6, fontSize: 11.5, fontWeight: 600
          }}>{c}</span>
        ))}
      </div>

      <div className="flow-card">
        <div className="flow-card__head"><h3>Pending approval ({pending.length})</h3><span className="flow-card__link">Bulk approve →</span></div>
        <div className="flow-card__body flow-card__body--flush">
          {pending.map((p, i) => (
            <div key={i} style={{
              display: "grid", gridTemplateColumns: "28px 1.6fr 1.2fr 100px 100px 80px auto",
              padding: "12px 14px", borderBottom: i < pending.length - 1 ? "1px solid var(--border)" : "none",
              alignItems: "center", gap: 12
            }}>
              <span className={`fm-avatar fm-avatar--sm fs-avatar--c${i + 1}`}>{p.who.split(" ").map(x => x[0]).slice(0, 2).join("")}</span>
              <div>
                <strong style={{ fontSize: 13 }}>{p.who}</strong>
                <small style={{ fontSize: 10.5 }}>requested {p.date}</small>
              </div>
              <div>
                <strong style={{ fontSize: 12.5 }}>{p.plan}</strong>
                <small style={{ fontSize: 10.5 }}>{p.mode} · ref #2{i}45</small>
              </div>
              <strong style={{ fontSize: 14, letterSpacing: "-0.015em", fontVariantNumeric: "tabular-nums" }}>₹{p.amount.toLocaleString("en-IN")}</strong>
              <span className="flow-tag flow-tag--payment">PENDING</span>
              <button className="flow-pill-btn" style={{ fontSize: 11, padding: "5px 12px" }}>Approve</button>
              <button className="flow-pill-btn flow-pill-btn--ghost" style={{ fontSize: 11, padding: "5px 10px", color: "var(--danger)", borderColor: "color-mix(in srgb, var(--danger) 30%, transparent)" }}>Reject</button>
            </div>
          ))}
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerBilling = FlowOwnerBilling;

// ── 8. Trainers ──────────────────────────────────────────────────────
function FlowOwnerTrainers() {
  return (
    <window.FlowOwnerChrome active="trainers" title="Trainers" crumb="Trainers" primaryAction="Add trainer">
      <p className="flow-page-desc">Manage your coaching staff, see their workload, and assign PT members.</p>

      <div className="flow-grid-3">
        <div className="flow-kpi flow-kpi--brand"><small>TOTAL TRAINERS</small><strong>2</strong><em>Priya N. · Vikram I.</em></div>
        <div className="flow-kpi flow-kpi--accent"><small>PT MEMBERS</small><strong>24</strong><em>all assigned</em></div>
        <div className="flow-kpi"><small>UNASSIGNED</small><strong>0</strong><em>no orphan PT members</em></div>
      </div>

      <div className="flow-grid-2">
        {FO2().trainers.map((t, i) => (
          <div key={t.name} className="flow-card">
            <div className="flow-card__body" style={{ display: "flex", gap: 14, alignItems: "center" }}>
              <span className={`fm-avatar fm-avatar--lg fs-avatar--c${t.color}`}>{t.initials}</span>
              <div style={{ flex: 1 }}>
                <strong style={{ fontSize: 16, fontWeight: 700, letterSpacing: "-0.015em" }}>{t.name}</strong>
                <div style={{ fontSize: 11.5, color: "var(--text-soft)" }}>{t.role} · joined Feb 2024</div>
                <div style={{ display: "flex", gap: 18, marginTop: 8 }}>
                  <div>
                    <small style={{ fontSize: 9, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase" }}>PT MEMBERS</small>
                    <div style={{ fontSize: 14, fontWeight: 700 }}>{t.members}</div>
                  </div>
                  <div>
                    <small style={{ fontSize: 9, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase" }}>TODAY</small>
                    <div style={{ fontSize: 14, fontWeight: 700 }}>{t.sessionsToday} sessions</div>
                  </div>
                  <div>
                    <small style={{ fontSize: 9, color: "var(--text-faint)", fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase" }}>UTILIZATION</small>
                    <div style={{ fontSize: 14, fontWeight: 700 }}>{[72, 65][i]}%</div>
                  </div>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ fontSize: 11, padding: "5px 10px" }}>View members</button>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ fontSize: 11, padding: "5px 10px" }}>Schedule</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerTrainers = FlowOwnerTrainers;

// ── 9. Training (PT sessions) ────────────────────────────────────────
function FlowOwnerTraining() {
  return (
    <window.FlowOwnerChrome active="training" title="Training & PT" crumb="Training" primaryAction="Book session">
      <div className="flow-grid-4">
        <div className="flow-kpi flow-kpi--brand"><small>TODAY</small><strong>5</strong><em>scheduled</em></div>
        <div className="flow-kpi"><small>THIS WEEK</small><strong>28</strong><em>across trainers</em></div>
        <div className="flow-kpi flow-kpi--accent"><small>COMPLETED</small><strong>96%</strong><em>last 30 days</em></div>
        <div className="flow-kpi flow-kpi--warn"><small>NO-SHOWS</small><strong>3</strong><em>last week</em></div>
      </div>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1.6fr 1fr" }}>
        <div className="flow-card">
          <div className="flow-card__head">
            <h3>Today · 5 sessions</h3>
            <div style={{ display: "flex", gap: 4 }}>
              {["Day", "Week", "Month"].map((v, i) => (
                <span key={v} style={{
                  background: i === 0 ? "var(--text)" : "var(--bg-subtle)",
                  color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
                  padding: "4px 9px", borderRadius: 5, fontSize: 10.5, fontWeight: 700
                }}>{v}</span>
              ))}
            </div>
          </div>
          <div className="flow-card__body flow-card__body--flush">
            {FO2().ptSessions.map((s, i) => (
              <div key={i} style={{
                display: "grid", gridTemplateColumns: "60px 1.4fr 1fr 80px 70px",
                padding: "10px 14px", borderBottom: i < FO2().ptSessions.length - 1 ? "1px solid var(--border)" : "none",
                alignItems: "center", gap: 10
              }}>
                <div>
                  <strong style={{ fontSize: 12, fontVariantNumeric: "tabular-nums" }}>{s.time}</strong>
                  <div style={{ fontSize: 9.5, color: "var(--text-faint)" }}>45m</div>
                </div>
                <div>
                  <strong style={{ fontSize: 12.5 }}>{s.member}</strong>
                  <div style={{ fontSize: 10.5, color: "var(--text-soft)" }}>{s.focus}</div>
                </div>
                <div style={{ fontSize: 11.5, color: "var(--text-soft)" }}>{s.trainer}</div>
                <span className={`flow-tag flow-tag--${s.status === "completed" ? "neutral" : s.status === "in_progress" ? "ok" : "noplan"}`}>
                  {s.status === "completed" ? "DONE" : s.status === "in_progress" ? "LIVE" : "SOON"}
                </span>
                <window.MIcons.More size={13} />
              </div>
            ))}
          </div>
        </div>

        <div className="flow-card">
          <div className="flow-card__head"><h3><window.MIcons.Calendar size={12} /> This week</h3></div>
          <div className="flow-card__body">
            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4 }}>
              {["M 25", "T 26", "W 27", "T 28", "F 29", "S 30", "S 31"].map((d, i) => (
                <div key={d} style={{
                  background: i === 3 ? "var(--brand)" : i < 3 ? "var(--bg-subtle)" : "var(--bg-elevated)",
                  border: i < 3 ? "none" : "1px solid var(--border)",
                  color: i === 3 ? "white" : "var(--text)",
                  borderRadius: 8, padding: "8px 4px", textAlign: "center", aspectRatio: "1"
                }}>
                  <div style={{ fontSize: 10, fontWeight: 700, opacity: 0.7 }}>{d.split(" ")[0]}</div>
                  <div style={{ fontSize: 14, fontWeight: 700, marginTop: 4 }}>{d.split(" ")[1]}</div>
                  <div style={{ fontSize: 9.5, marginTop: 6, opacity: 0.75 }}>{[4, 6, 0, 5, 3, 8, 2][i]} ses.</div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--border)" }}>
              <span className="flow-eyebrow">UPCOMING THIS WEEK</span>
              {[
                { t: "Mon 6:30 AM", m: "Aanya · Push tech" },
                { t: "Wed 7:00 PM", m: "Karthik · Cardio plan" },
                { t: "Sat 8:00 AM", m: "Reyansh · Deadlift" }
              ].map((u, i) => (
                <div key={i} style={{ padding: "5px 0", fontSize: 11.5, borderBottom: i < 2 ? "1px solid var(--border)" : "none" }}>
                  <strong>{u.t}</strong>
                  <div style={{ color: "var(--text-soft)", fontSize: 10.5 }}>{u.m}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerTraining = FlowOwnerTraining;

// ── 10. Reports ──────────────────────────────────────────────────────
function FlowOwnerReports() {
  return (
    <window.FlowOwnerChrome active="reports" title="Reports & analytics" crumb="Reports" primaryAction="Export PDF">
      <p className="flow-page-desc">
        Attendance, revenue, member growth, and program effectiveness — for {`Titan Strength · Bandra`}.
      </p>

      <div className="flow-grid-4">
        <div className="flow-kpi flow-kpi--brand"><small>RETENTION</small><strong>84%</strong><em>last 90 days</em></div>
        <div className="flow-kpi flow-kpi--accent"><small>AVG SESSIONS / WK</small><strong>3.2</strong><em>per member</em></div>
        <div className="flow-kpi"><small>PT UTILIZATION</small><strong>72%</strong><em>across trainers</em></div>
        <div className="flow-kpi flow-kpi--warn"><small>LTV</small><strong>₹28.4k</strong><em>per member</em></div>
      </div>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1.6fr 1fr" }}>
        <div className="flow-card">
          <div className="flow-card__head">
            <h3><window.MIcons.Chart size={12} /> Attendance · last 14 days</h3>
            <div style={{ display: "flex", gap: 4 }}>
              {["14d", "30d", "90d"].map((v, i) => (
                <span key={v} style={{
                  background: i === 0 ? "var(--text)" : "var(--bg-subtle)",
                  color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
                  padding: "3px 8px", borderRadius: 5, fontSize: 10, fontWeight: 700
                }}>{v}</span>
              ))}
            </div>
          </div>
          <div className="flow-card__body">
            <div style={{ display: "grid", gridTemplateColumns: "repeat(14, 1fr)", gap: 3, alignItems: "end", height: 110 }}>
              {[12, 18, 22, 16, 14, 8, 6, 24, 28, 19, 17, 14, 22, 27].map((v, i) => {
                const h = (v / 28) * 100;
                const isToday = i === 13;
                return (
                  <div key={i} style={{
                    height: `${h}%`,
                    background: isToday ? "var(--brand)" : "color-mix(in srgb, var(--brand) 40%, var(--bg-subtle))",
                    borderRadius: "3px 3px 0 0", minHeight: 4
                  }} />
                );
              })}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6, fontSize: 10, color: "var(--text-faint)", fontWeight: 600, letterSpacing: "0.06em" }}>
              <span>2 WEEKS AGO</span>
              <span>TODAY</span>
            </div>
          </div>
        </div>

        <div className="flow-card">
          <div className="flow-card__head"><h3><window.MIcons.Heart size={12} /> Membership mix</h3></div>
          <div className="flow-card__body">
            <div style={{ display: "flex", height: 14, borderRadius: 999, overflow: "hidden", marginBottom: 12 }}>
              {FO2().packages.map((p) => (
                <div key={p.name} style={{
                  flex: p.members,
                  background: { "Annual Pro": "var(--brand)", "Quarterly Strength": "var(--accent)", "Half-year PT": "var(--gold)", "Monthly Drop-in": "var(--danger)", "Annual + PT": "var(--text-soft)" }[p.name]
                }} />
              ))}
            </div>
            {FO2().packages.map((p) => (
              <div key={p.name} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0", fontSize: 11.5 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 2, background: { "Annual Pro": "var(--brand)", "Quarterly Strength": "var(--accent)", "Half-year PT": "var(--gold)", "Monthly Drop-in": "var(--danger)", "Annual + PT": "var(--text-soft)" }[p.name] }} />
                  <span>{p.name}</span>
                </div>
                <strong>{p.members}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerReports = FlowOwnerReports;

// ── 11. Notifications ────────────────────────────────────────────────
function FlowOwnerNotifications() {
  return (
    <window.FlowOwnerChrome active="notifications" title="Notifications" crumb="Notifications" primaryAction="Mark all read">
      <p className="flow-page-desc">All updates from your gym — joins, payments, sessions, member feedback.</p>

      <div style={{ display: "flex", gap: 4 }}>
        {["All 28", "Unread 3", "Mentions", "Payments", "Members"].map((c, i) => (
          <span key={c} style={{
            background: i === 0 ? "var(--text)" : "transparent",
            color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
            border: i === 0 ? "none" : "1px solid var(--border)",
            padding: "5px 11px", borderRadius: 6, fontSize: 11, fontWeight: 600
          }}>{c}</span>
        ))}
      </div>

      <div className="flow-card">
        <div className="flow-card__body flow-card__body--flush">
          {[
            { kind: "payment", who: "Ananya Bose", what: "submitted cash payment of ₹18,500", at: "2h ago", unread: true },
            { kind: "joined", who: "Karthik Reddy", what: "joined the gym · Monthly plan", at: "3h ago", unread: true },
            { kind: "session_done", who: "Aanya Sharma", what: "completed Push B (45 min)", at: "4h ago", unread: false },
            { kind: "pr", who: "Ishaan Kapoor", what: "hit a new bench PR · 95kg × 5", at: "5h ago", unread: true },
            { kind: "joined", who: "Veer Tiwari", what: "joined the gym · Annual Pro", at: "yesterday", unread: false },
            { kind: "expiring", who: "Devansh Joshi", what: "membership expiring in 5 days", at: "yesterday", unread: false },
            { kind: "feedback", who: "Sara D'Souza", what: "left a 5-star review for Coach Priya", at: "2d ago", unread: false }
          ].map((n, i) => (
            <div key={i} style={{
              display: "grid", gridTemplateColumns: "30px 1fr auto auto",
              padding: "10px 14px", borderBottom: i < 6 ? "1px solid var(--border)" : "none",
              alignItems: "center", gap: 12, background: n.unread ? "color-mix(in srgb, var(--brand) 4%, transparent)" : "transparent"
            }}>
              <span className={`fm-avatar fm-avatar--sm fs-avatar--c${(i % 6) + 1}`}>{n.who.split(" ").map(x => x[0]).slice(0, 2).join("")}</span>
              <div>
                <span style={{ fontSize: 12.5 }}><strong>{n.who}</strong> {n.what}</span>
                <div style={{ fontSize: 10.5, color: "var(--text-faint)" }}>{n.at}</div>
              </div>
              {n.unread && <span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--brand)" }} />}
              <window.MIcons.More size={13} />
            </div>
          ))}
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerNotifications = FlowOwnerNotifications;

// ── 12. Settings ─────────────────────────────────────────────────────
function FlowOwnerSettings() {
  return (
    <window.FlowOwnerChrome active="settings" title="Gym settings" crumb="Settings" primaryAction="Save changes">
      <div className="flow-grid-2" style={{ gridTemplateColumns: "200px 1fr" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {["Gym profile", "Branding", "Operating hours", "Notifications", "Integrations", "Billing & taxes", "API & webhooks", "Danger zone"].map((s, i) => (
            <div key={s} style={{
              padding: "8px 12px", borderRadius: 8,
              background: i === 0 ? "var(--brand-soft)" : "transparent",
              color: i === 0 ? "var(--brand)" : "var(--text-soft)",
              fontSize: 12, fontWeight: 600, cursor: "default"
            }}>{s}</div>
          ))}
        </div>

        <div className="flow-stack flow-stack--gap-12">
          <div className="flow-card">
            <div className="flow-card__head"><h3>Gym profile</h3></div>
            <div className="flow-card__body" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {[
                { l: "Gym name", v: "Titan Strength" },
                { l: "Branch", v: "Bandra West" },
                { l: "City", v: "Mumbai, MH" },
                { l: "Address", v: "12 Linking Road, Bandra W" },
                { l: "Phone", v: "+91 22 1234 5678" },
                { l: "Capacity", v: "35 members at peak" }
              ].map((f) => (
                <div key={f.l}>
                  <small style={{ fontSize: 10, fontWeight: 700, color: "var(--text-faint)", letterSpacing: "0.07em", textTransform: "uppercase", marginBottom: 4, display: "block" }}>{f.l}</small>
                  <div style={{
                    background: "var(--bg-subtle)", border: "1px solid transparent",
                    borderRadius: 8, padding: "8px 10px", fontSize: 12.5, color: "var(--text)"
                  }}>{f.v}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="flow-card">
            <div className="flow-card__head"><h3>Logo & branding</h3></div>
            <div className="flow-card__body" style={{ display: "flex", gap: 16, alignItems: "center" }}>
              <div style={{
                width: 60, height: 60, borderRadius: 14, background: "linear-gradient(135deg, var(--brand), var(--brand-strong))",
                color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 22, letterSpacing: "-0.04em"
              }}>TS</div>
              <div style={{ flex: 1 }}>
                <strong style={{ fontSize: 13 }}>Titan Strength · Bandra</strong>
                <div style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 2 }}>Upload a square logo (min 256×256, PNG or SVG)</div>
              </div>
              <button className="flow-pill-btn flow-pill-btn--ghost">Replace</button>
            </div>
          </div>
        </div>
      </div>
    </window.FlowOwnerChrome>
  );
}
window.FlowOwnerSettings = FlowOwnerSettings;
