// E2E Flow — Trainer screens (desktop)

const FT = () => window.FLOW_MOCK;

// Trainer chrome (lighter than owner)
function FlowTrainerChrome({ active, title, crumb, children }) {
  const items = [
    { v: "today", l: "Today" },
    { v: "members", l: "My members", count: 14 },
    { v: "sessions", l: "Sessions" },
    { v: "programs", l: "Programs" }
  ];
  return (
    <div className="flow-owner">
      <aside className="flow-owner__side">
        <div className="flow-owner__brand">
          <span className="flow-owner__brand-mark">
            <window.MIcons.Lightning size={12} />
          </span>
          <span>FitSplit</span>
        </div>
        <span className="flow-owner__nav-group">TRAINER</span>
        {items.map((it) => (
          <div key={it.v} className={`flow-owner__nav-item ${active === it.v ? "flow-owner__nav-item--on" : ""}`}>
            <span>{it.l}</span>
            {it.count && <span className="flow-owner__nav-item-count">{it.count}</span>}
          </div>
        ))}
        <div style={{ marginTop: "auto", padding: 8, display: "flex", alignItems: "center", gap: 8, background: "var(--bg-subtle)", borderRadius: 10 }}>
          <span className="fm-avatar fm-avatar--sm fs-avatar--c1">PN</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700 }}>{FT().trainer.name}</div>
            <small style={{ fontSize: 10, color: "var(--text-soft)" }}>Head Coach</small>
          </div>
        </div>
      </aside>
      <div className="flow-owner__main">
        <div className="flow-owner__top">
          <div>
            <div className="flow-owner__crumb">Trainer / {crumb}</div>
            <h2 className="flow-owner__title">{title}</h2>
          </div>
          <div className="flow-owner__top-right">
            <button className="flow-pill-btn flow-pill-btn--ghost">
              <window.MIcons.Bell size={12} />
            </button>
            <button className="flow-pill-btn">+ Book session</button>
          </div>
        </div>
        <div className="flow-owner__content">{children}</div>
      </div>
    </div>
  );
}
window.FlowTrainerChrome = FlowTrainerChrome;

// ── Trainer Dashboard ──────────────────────────────────────────────────
function FlowTrainerDashboard() {
  const t = FT().trainer;
  return (
    <FlowTrainerChrome active="today" crumb="Today" title="Good morning, Priya">
      <p className="flow-page-desc" style={{ marginTop: -4 }}>
        5 PT sessions today · {t.members} active members assigned to you · 14 completed this week.
      </p>

      <div className="flow-grid-4">
        <div className="flow-kpi flow-kpi--brand">
          <small>TODAY'S SESSIONS</small><strong>{t.todaySessions}</strong>
          <em>2 done · 1 live</em>
        </div>
        <div className="flow-kpi flow-kpi--accent">
          <small>MY MEMBERS</small><strong>{t.members}</strong>
          <em>3 need a check-in</em>
        </div>
        <div className="flow-kpi flow-kpi--warn">
          <small>THIS WEEK</small><strong>{t.completedThisWeek}</strong>
          <em>completed sessions</em>
        </div>
        <div className="flow-kpi">
          <small>NEXT SESSION</small><strong>10:00</strong>
          <em>Sara D'Souza · Mobility</em>
        </div>
      </div>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1.5fr 1fr" }}>
        <div className="flow-card">
          <div className="flow-card__head">
            <h3><window.MIcons.Calendar size={12} /> Today's schedule</h3>
            <span className="flow-card__link">All sessions →</span>
          </div>
          <div className="flow-card__body flow-card__body--flush">
            {FT().ptSessions.map((s, i) => (
              <div key={i} className="flow-row" style={{ display: "grid", gridTemplateColumns: "40px 1fr auto" }}>
                <strong style={{ fontVariantNumeric: "tabular-nums" }}>{s.time}</strong>
                <div>
                  <strong>{s.member}</strong>
                  <small>{s.focus}</small>
                </div>
                <span className={`flow-tag flow-tag--${s.status === "completed" ? "neutral" : s.status === "in_progress" ? "ok" : "noplan"}`}>
                  {s.status === "completed" ? "DONE" : s.status === "in_progress" ? "LIVE" : "SOON"}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="flow-card">
          <div className="flow-card__head">
            <h3><window.MIcons.Sparkle size={12} /> Members needing attention</h3>
          </div>
          <div className="flow-card__body flow-card__body--flush">
            {[
              { who: "Aanya Sharma", what: "missed session 3 days ago" },
              { who: "Devansh Joshi", what: "form check overdue" },
              { who: "Sara D'Souza", what: "ready for progressive overload" }
            ].map((p, i) => (
              <div key={i} className="flow-row" style={{ display: "grid", gridTemplateColumns: "28px 1fr auto" }}>
                <span className="fm-avatar fm-avatar--sm fs-avatar--c2">{p.who.split(" ").map(x => x[0]).slice(0, 2).join("")}</span>
                <div>
                  <strong>{p.who}</strong>
                  <small>{p.what}</small>
                </div>
                <button className="flow-pill-btn flow-pill-btn--ghost" style={{ fontSize: 10, padding: "3px 8px" }}>Open</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </FlowTrainerChrome>
  );
}
window.FlowTrainerDashboard = FlowTrainerDashboard;

// ── Trainer Members ────────────────────────────────────────────────────
function FlowTrainerMembers() {
  return (
    <FlowTrainerChrome active="members" crumb="My members" title="My members (14)">
      <div className="flow-card">
        <div className="flow-card__head" style={{ gap: 10 }}>
          <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, background: "var(--bg-subtle)", borderRadius: 8, padding: "5px 10px", maxWidth: 280 }}>
            <window.MIcons.Search size={13} />
            <span style={{ fontSize: 12, color: "var(--text-soft)" }}>Search…</span>
          </div>
          <div style={{ display: "flex", gap: 4 }}>
            {["All 14", "Active", "Inactive", "Needs check-in"].map((c, i) => (
              <span key={c} style={{
                background: i === 0 ? "var(--text)" : "var(--bg-subtle)",
                color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
                padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600
              }}>{c}</span>
            ))}
          </div>
        </div>
        <div className="flow-card__body flow-card__body--flush">
          {FT().members.slice(0, 6).map((m, i) => (
            <div key={m.name} className="flow-row" style={{ display: "grid", gridTemplateColumns: "28px 1.4fr 1fr 1fr 100px auto", padding: "10px 14px" }}>
              <span className={`fm-avatar fm-avatar--sm fs-avatar--c${(i % 6) + 1}`}>{m.name.split(" ").map(x => x[0]).slice(0, 2).join("")}</span>
              <div>
                <strong>{m.name}</strong>
                <small>@{m.handle}</small>
              </div>
              <div>
                <small style={{ fontSize: 9.5, color: "var(--text-faint)", textTransform: "uppercase", letterSpacing: "0.06em", fontWeight: 700 }}>PROGRAM</small>
                <div style={{ fontSize: 11.5 }}>{i % 2 === 0 ? "Hypertrophy 12wk" : "Upper/Lower"}</div>
              </div>
              <div>
                <small style={{ fontSize: 9.5, color: "var(--text-faint)", textTransform: "uppercase", letterSpacing: "0.06em", fontWeight: 700 }}>LAST SESSION</small>
                <div style={{ fontSize: 11.5 }}>{["Today", "2d ago", "5d ago", "Yesterday", "Today", "1w ago"][i]}</div>
              </div>
              <span className={`flow-tag flow-tag--${m.state === "ok" ? "ok" : m.state === "expired" ? "expired" : "noplan"}`}>
                {m.state === "ok" ? "ACTIVE" : m.state === "expired" ? "EXPIRED" : m.state === "noplan" ? "CHECK-IN" : "ACTIVE"}
              </span>
              <window.MIcons.ChevR size={14} />
            </div>
          ))}
        </div>
      </div>
    </FlowTrainerChrome>
  );
}
window.FlowTrainerMembers = FlowTrainerMembers;

// ── Trainer Session Detail ─────────────────────────────────────────────
function FlowTrainerSession() {
  return (
    <FlowTrainerChrome active="sessions" crumb="Sessions / Today 08:00" title="Squat 1RM test · Vihaan Gupta">
      <div className="flow-grid-2" style={{ gridTemplateColumns: "1.4fr 1fr" }}>
        <div className="flow-card">
          <div className="flow-card__head">
            <h3>Session timeline</h3>
            <span style={{
              background: "var(--brand)", color: "white",
              padding: "3px 10px", borderRadius: 999, fontSize: 10, fontWeight: 800, letterSpacing: "0.07em"
            }}>● LIVE</span>
          </div>
          <div className="flow-card__body">
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
              <div>
                <small style={{ fontSize: 10, color: "var(--text-faint)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.07em" }}>STARTED</small>
                <div style={{ fontSize: 14, fontWeight: 700 }}>08:00</div>
              </div>
              <div>
                <small style={{ fontSize: 10, color: "var(--text-faint)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.07em" }}>DURATION</small>
                <div style={{ fontSize: 14, fontWeight: 700 }}>45 min</div>
              </div>
              <div>
                <small style={{ fontSize: 10, color: "var(--text-faint)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.07em" }}>ELAPSED</small>
                <div style={{ fontSize: 14, fontWeight: 700, color: "var(--brand)" }}>22 min</div>
              </div>
            </div>
            <div style={{ height: 5, background: "var(--bg-subtle)", borderRadius: 999, overflow: "hidden", marginBottom: 18 }}>
              <div style={{ width: "49%", height: "100%", background: "var(--brand)" }} />
            </div>

            <span className="flow-eyebrow">PROGRESS · 1RM TEST</span>
            {[
              { set: "Warm-up · 60kg × 5", done: true },
              { set: "Working · 80kg × 3", done: true },
              { set: "Working · 90kg × 1", done: true },
              { set: "Test · 100kg × 1", done: false, active: true },
              { set: "Recovery · 70kg × 5", done: false }
            ].map((s, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "8px 0", borderBottom: i < 4 ? "1px solid var(--border)" : "none"
              }}>
                <div style={{
                  width: 18, height: 18, borderRadius: "50%",
                  border: "1.5px solid var(--border-strong)",
                  background: s.done ? "var(--brand)" : s.active ? "transparent" : "transparent",
                  borderColor: s.done ? "var(--brand)" : s.active ? "var(--brand)" : "var(--border-strong)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "white", fontSize: 9
                }}>{s.done ? "✓" : ""}</div>
                <span style={{ fontSize: 12.5, fontWeight: s.active ? 700 : 500, color: s.active ? "var(--text)" : s.done ? "var(--text-soft)" : "var(--text)" }}>
                  {s.set}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="flow-stack flow-stack--gap-12">
          <div className="flow-card">
            <div className="flow-card__head"><h3>Member</h3></div>
            <div className="flow-card__body">
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <span className="fm-avatar fm-avatar--md fs-avatar--c3">VG</span>
                <div>
                  <strong style={{ fontSize: 13.5, fontWeight: 700 }}>Vihaan Gupta</strong>
                  <div style={{ fontSize: 11, color: "var(--text-soft)" }}>@vihaan_g · Annual + PT</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                <div style={{ background: "var(--bg-subtle)", borderRadius: 8, padding: 8 }}>
                  <small style={{ fontSize: 9.5, color: "var(--text-faint)", letterSpacing: "0.06em", fontWeight: 700 }}>LAST SQUAT 1RM</small>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>95<small style={{ fontSize: 10, color: "var(--text-soft)" }}>kg</small></div>
                </div>
                <div style={{ background: "var(--bg-subtle)", borderRadius: 8, padding: 8 }}>
                  <small style={{ fontSize: 9.5, color: "var(--text-faint)", letterSpacing: "0.06em", fontWeight: 700 }}>BODY WEIGHT</small>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>78<small style={{ fontSize: 10, color: "var(--text-soft)" }}>kg</small></div>
                </div>
              </div>
            </div>
          </div>

          <div className="flow-card">
            <div className="flow-card__head"><h3>Add note</h3></div>
            <div className="flow-card__body">
              <div style={{
                background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: 8,
                padding: "8px 10px", fontSize: 11, color: "var(--text-soft)", marginBottom: 6, minHeight: 50
              }}>Form looked clean on 90kg. Going for 100 next. Watch his knee tracking on the way up.</div>
              <button className="flow-pill-btn" style={{ width: "100%", padding: 7, fontSize: 11 }}>Save note</button>
            </div>
          </div>
        </div>
      </div>
    </FlowTrainerChrome>
  );
}
window.FlowTrainerSession = FlowTrainerSession;
