// E2E Flow — Public screens (visitor + login + about)

const { useState: useStateP } = React;

// ── Reusable compact chrome for owner-side pages ───────────────────────
function FlowOwnerChrome({ active, children, title, crumb, kpiAlert, primaryAction = "Add member" }) {
  const items = [
    { v: "dashboard", l: "Dashboard" },
    { v: "members", l: "Members", count: 247 },
    { v: "training", l: "Training" },
    { v: "programs", l: "Programs" },
    { v: "packages", l: "Packages" },
    { v: "billing", l: "Billing", alert: 7 },
    { v: "trainers", l: "Trainers" },
    { v: "exercises", l: "Exercises" },
    { v: "reports", l: "Reports" },
    { v: "notifications", l: "Notifications", alert: 3 }
  ];
  const settings = [
    { v: "settings", l: "Settings" }
  ];
  return (
    <div className="flow-owner">
      <aside className="flow-owner__side">
        <div className="flow-owner__brand">
          <span className="flow-owner__brand-mark">
            <window.MIcons.Lightning size={12} />
          </span>
          <span>FitSplit</span>
        </div>
        <span className="flow-owner__nav-group">MANAGE</span>
        {items.map((it) => (
          <div
            key={it.v}
            className={`flow-owner__nav-item ${active === it.v ? "flow-owner__nav-item--on" : ""}`}
          >
            <span>{it.l}</span>
            {it.alert ? (
              <span className="flow-owner__nav-item-count flow-owner__nav-item-count--alert">{it.alert}</span>
            ) : it.count ? (
              <span className="flow-owner__nav-item-count">{it.count}</span>
            ) : null}
          </div>
        ))}
        <span className="flow-owner__nav-group">SETTINGS</span>
        {settings.map((it) => (
          <div key={it.v} className={`flow-owner__nav-item ${active === it.v ? "flow-owner__nav-item--on" : ""}`}>
            <span>{it.l}</span>
          </div>
        ))}
      </aside>
      <div className="flow-owner__main">
        <div className="flow-owner__top">
          <div>
            <div className="flow-owner__crumb">Dashboard / {crumb}</div>
            <h2 className="flow-owner__title">{title}</h2>
          </div>
          <div className="flow-owner__top-right">
            <button className="flow-pill-btn flow-pill-btn--ghost">Export</button>
            <button className="flow-pill-btn">+ {primaryAction}</button>
          </div>
        </div>
        <div className="flow-owner__content">
          {children}
        </div>
      </div>
    </div>
  );
}

// ── Reusable compact mobile chrome (member) ────────────────────────────
function FlowMobileChrome({ activeTab = "home", children, status = "9:41" }) {
  const tabs = [
    { v: "home", l: "Coach", icon: <window.MIcons.Mail size={18} /> },
    { v: "train", l: "Train", icon: <window.MIcons.Dumbbell size={18} /> },
    { v: "progress", l: "Progress", icon: <window.MIcons.Chart size={18} /> },
    { v: "profile", l: "Profile", icon: <window.MIcons.User size={18} /> }
  ];
  return (
    <div className="flow-mobile">
      <div className="flow-mobile__status">
        <span>{status}</span>
        <span>● ● ●</span>
      </div>
      <div className="flow-mobile__scroll">
        {children}
      </div>
      <div className="flow-mobile__tabbar">
        {tabs.map((t) => (
          <button key={t.v} className={`flow-mobile__tab ${activeTab === t.v ? "flow-mobile__tab--on" : ""}`}>
            {t.icon}
            <span>{t.l}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

window.FlowOwnerChrome = FlowOwnerChrome;
window.FlowMobileChrome = FlowMobileChrome;

// ──────────────────────────────────────────────────────────────────────
// PUBLIC SCREENS
// ──────────────────────────────────────────────────────────────────────

function Step({ num, role, name, path, children, withChrome = true }) {
  return (
    <div className="flow-step">
      <div className="flow-step__label">
        <span className="flow-step__num">{num}</span>
        <span>{role} · {name}</span>
        <span className="flow-step__path">{path}</span>
      </div>
      <div className="flow-step__body">
        {children}
      </div>
    </div>
  );
}
window.FlowStep = Step;

// 1. Landing page (compact reference)
function FlowLanding() {
  return (
    <div className="flow-landing" style={{
      width: "100%", height: "100%", overflow: "hidden",
      display: "flex", flexDirection: "column", background: "var(--bg)"
    }}>
      <header style={{
        display: "flex", justifyContent: "space-between", alignItems: "center",
        padding: "12px 24px", borderBottom: "1px solid var(--border)",
        background: "color-mix(in srgb, var(--bg) 88%, transparent)"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 700, fontSize: 14 }}>
          <span style={{ width: 24, height: 24, borderRadius: 6, background: "var(--brand)", color: "white", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <window.MIcons.Lightning size={13} />
          </span>
          FitSplit
        </div>
        <nav style={{ display: "flex", gap: 14, fontSize: 12, color: "var(--text-soft)", fontWeight: 500 }}>
          <span>Product</span><span>Pricing</span><span>Customers</span><span>Resources</span>
        </nav>
        <div style={{ display: "flex", gap: 6 }}>
          <button className="flow-pill-btn flow-pill-btn--ghost">Log in</button>
          <button className="flow-pill-btn">Start free trial</button>
        </div>
      </header>

      <div style={{
        flex: 1, overflow: "auto",
        padding: "40px 24px", textAlign: "center",
        background: "radial-gradient(ellipse 800px 400px at 50% 0%, color-mix(in srgb, var(--brand) 14%, transparent), transparent 70%)"
      }}>
        <span className="flow-eyebrow" style={{
          background: "var(--bg-elevated)", border: "1px solid var(--border)",
          borderRadius: 999, padding: "5px 12px", display: "inline-block", marginBottom: 16
        }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--brand)", display: "inline-block", marginRight: 6, verticalAlign: "middle" }} />
          Workout delivery for modern gyms
        </span>
        <h1 style={{
          fontSize: 38, fontWeight: 700, margin: "0 0 12px",
          letterSpacing: "-0.04em", lineHeight: 1.05
        }}>
          Structured workouts.<br />
          <span style={{
            background: "linear-gradient(135deg, var(--brand), var(--accent))",
            WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent"
          }}>Delivered to every member.</span>
        </h1>
        <p style={{ fontSize: 14, color: "var(--text-soft)", maxWidth: 460, margin: "0 auto 22px" }}>
          One focused workspace to assign plans, guide sessions, and track progress.
        </p>
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 28 }}>
          <button className="flow-pill-btn" style={{ padding: "9px 18px", fontSize: 13 }}>Start free trial →</button>
          <button className="flow-pill-btn flow-pill-btn--ghost" style={{ padding: "9px 18px", fontSize: 13 }}>Watch demo</button>
        </div>

        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8,
          maxWidth: 580, margin: "0 auto"
        }}>
          {[
            { v: "248", l: "gyms" },
            { v: "86%", l: "completion rate" },
            { v: "2 min", l: "to assign" },
            { v: "32k", l: "workouts/mo" }
          ].map((s) => (
            <div key={s.l} style={{
              background: "var(--bg-elevated)", border: "1px solid var(--border)",
              borderRadius: 10, padding: "10px"
            }}>
              <strong style={{ fontSize: 22, fontWeight: 700, letterSpacing: "-0.03em", display: "block" }}>{s.v}</strong>
              <span style={{ fontSize: 10, color: "var(--text-soft)", textTransform: "uppercase", fontWeight: 600 }}>{s.l}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
window.FlowLanding = FlowLanding;

// 2. Login modal (full screen for flow)
function FlowLogin() {
  const [mode, setMode] = useStateP("member");
  return (
    <div style={{
      width: "100%", height: "100%", background: "var(--bg)",
      display: "flex", alignItems: "center", justifyContent: "center",
      backgroundImage: "radial-gradient(ellipse 600px 400px at 50% 30%, color-mix(in srgb, var(--brand) 12%, transparent), transparent 70%)"
    }}>
      <div style={{
        background: "var(--bg-elevated)", borderRadius: 16, padding: 24,
        width: 360, border: "1px solid var(--border)",
        boxShadow: "0 30px 80px rgba(0,0,0,0.15)"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16, fontWeight: 700, fontSize: 15 }}>
          <span style={{ width: 24, height: 24, borderRadius: 6, background: "var(--brand)", color: "white", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <window.MIcons.Lightning size={13} />
          </span>
          FitSplit
        </div>
        <h3 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 6px", letterSpacing: "-0.02em" }}>Access your workspace</h3>
        <p style={{ fontSize: 12, color: "var(--text-soft)", margin: "0 0 16px" }}>
          Members use mobile + PIN. Staff use username + password.
        </p>
        <div style={{
          display: "flex", background: "var(--bg-subtle)", borderRadius: 8, padding: 3, marginBottom: 14
        }}>
          {["member", "staff"].map((t) => (
            <button
              key={t}
              onClick={() => setMode(t)}
              style={{
                flex: 1, padding: "6px", border: "none", cursor: "pointer",
                background: mode === t ? "var(--bg-elevated)" : "transparent",
                color: mode === t ? "var(--text)" : "var(--text-soft)",
                borderRadius: 6, fontWeight: 600, fontSize: 11.5,
                fontFamily: "inherit", textTransform: "capitalize"
              }}
            >
              {t}
            </button>
          ))}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div>
            <label style={{ fontSize: 11, fontWeight: 600, color: "var(--text)", display: "block", marginBottom: 3 }}>
              {mode === "member" ? "Mobile or username" : "Username"}
            </label>
            <div style={{ background: "var(--bg-subtle)", borderRadius: 8, padding: "8px 10px", fontSize: 12, color: "var(--text-soft)" }}>
              {mode === "member" ? "+91 98765 12345" : "priya.nair"}
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, fontWeight: 600, color: "var(--text)", display: "block", marginBottom: 3 }}>
              {mode === "member" ? "4-digit PIN" : "Password"}
            </label>
            <div style={{ background: "var(--bg-subtle)", borderRadius: 8, padding: "8px 10px", fontSize: 12, color: "var(--text-soft)" }}>
              {mode === "member" ? "• • • •" : "••••••••••"}
            </div>
          </div>
          <button className="flow-pill-btn" style={{ width: "100%", padding: "10px", fontSize: 13, marginTop: 4 }}>Log in</button>
          <a style={{ textAlign: "center", fontSize: 11, color: "var(--brand)", fontWeight: 600, marginTop: 4 }}>Forgot password?</a>
        </div>
      </div>
    </div>
  );
}
window.FlowLogin = FlowLogin;

// 3. About page (compact)
function FlowAbout() {
  return (
    <div style={{
      width: "100%", height: "100%", background: "var(--bg)",
      display: "flex", flexDirection: "column", overflow: "hidden"
    }}>
      <header style={{
        display: "flex", justifyContent: "space-between", alignItems: "center",
        padding: "12px 24px", borderBottom: "1px solid var(--border)"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 700, fontSize: 14 }}>
          <span style={{ width: 24, height: 24, borderRadius: 6, background: "var(--brand)", color: "white", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <window.MIcons.Lightning size={13} />
          </span>
          FitSplit
        </div>
        <nav style={{ display: "flex", gap: 14, fontSize: 12, color: "var(--text-soft)", fontWeight: 500 }}>
          <span>Product</span><span>Pricing</span><span>Customers</span><span style={{ color: "var(--text)" }}>About</span>
        </nav>
        <button className="flow-pill-btn">Start free trial</button>
      </header>
      <div style={{ flex: 1, overflow: "auto", padding: "48px 32px" }}>
        <div style={{ maxWidth: 720, margin: "0 auto" }}>
          <span className="flow-eyebrow" style={{ color: "var(--brand)", fontWeight: 700 }}>OUR STORY</span>
          <h1 style={{ fontSize: 36, fontWeight: 700, margin: "8px 0 16px", letterSpacing: "-0.035em", lineHeight: 1.1 }}>
            Built by gym owners,<br />for gym owners.
          </h1>
          <p style={{ fontSize: 15, color: "var(--text-soft)", lineHeight: 1.55, marginBottom: 28, maxWidth: 580 }}>
            FitSplit started in a 200-member gym in Bandra. We were tracking workouts in Google Sheets,
            chasing renewals on WhatsApp, and writing programs on the backs of notebooks.
            There had to be a better way. So we built it.
          </p>

          <div style={{
            display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 32
          }}>
            {[
              { l: "Founded", v: "2024" },
              { l: "Based in", v: "Mumbai" },
              { l: "Team", v: "8 people" }
            ].map((s) => (
              <div key={s.l} style={{
                background: "var(--bg-elevated)", border: "1px solid var(--border)",
                borderRadius: 12, padding: "16px 18px"
              }}>
                <strong style={{ fontSize: 24, fontWeight: 700, letterSpacing: "-0.025em", display: "block" }}>{s.v}</strong>
                <span style={{ fontSize: 11, color: "var(--text-soft)", textTransform: "uppercase", fontWeight: 600, letterSpacing: "0.06em" }}>{s.l}</span>
              </div>
            ))}
          </div>

          <h2 style={{ fontSize: 22, fontWeight: 700, letterSpacing: "-0.025em", margin: "0 0 12px" }}>What we believe</h2>
          <p style={{ fontSize: 14, color: "var(--text-soft)", lineHeight: 1.6 }}>
            Gyms are coaching businesses, not key-card businesses. Software should make coaches more effective,
            not turn them into admins. Every member deserves a clear plan and a coach who notices when they don't show up.
          </p>
        </div>
      </div>
    </div>
  );
}
window.FlowAbout = FlowAbout;
