// Mock data for E2E flow screens — covers every role's pages.
window.FLOW_MOCK = {
  brand: { name: "FitSplit" },

  member: {
    firstName: "Aanya", lastName: "Sharma", initials: "AS",
    handle: "aanya.s", mobile: "+91 98765 12345",
    avatarColor: 1,
    membership: { plan: "Annual Pro", expiry: "12 Aug 2026", daysLeft: 76, status: "active" },
    goal: "Build muscle", level: "Intermediate",
    streak: 7, daysThisWeek: 3, target: 4,
    sets: 47, bench: 52.5
  },

  trainer: {
    name: "Priya Nair", initials: "PN",
    members: 24,
    todaySessions: 5,
    completedThisWeek: 14
  },

  owner: {
    name: "Priya Nair", initials: "PN",
    gym: { name: "Titan Strength", branch: "Bandra West" }
  },

  admin: {
    name: "Vikram Iyer", initials: "VI",
    totalGyms: 12,
    totalMembers: 2840,
    activeGyms: 11
  },

  // Reusable lists
  members: [
    { name: "Aanya Sharma", handle: "aanya.s", plan: "Annual Pro", trainer: "Priya N.", state: "ok", expiry: "12 Aug" },
    { name: "Rohan Mehta", handle: "rohan_m", plan: "Annual Pro", trainer: "Vikram I.", state: "expired", expiry: "lapsed 4d" },
    { name: "Ishaan Kapoor", handle: "ishaan.k", plan: "Quarterly", trainer: "Vikram I.", state: "ok", expiry: "8 Jul" },
    { name: "Meera Iyer", handle: "meera", plan: "Annual + PT", trainer: "Priya N.", state: "ok", expiry: "2 Dec" },
    { name: "Karthik Reddy", handle: "karthik.r", plan: "Monthly", trainer: null, state: "noplan", expiry: "20 Jun" },
    { name: "Ananya Bose", handle: "ananya.b", plan: "Half-year PT", trainer: "Priya N.", state: "payment", expiry: "—" },
    { name: "Devansh Joshi", handle: "dev_joshi", plan: "Quarterly", trainer: "Vikram I.", state: "expiring", expiry: "in 5d" },
    { name: "Pari Saxena", handle: "pari", plan: "Annual Pro", trainer: null, state: "noplan", expiry: "20 Jan" }
  ],

  programs: [
    { title: "Hypertrophy 12wk", level: "Intermediate", duration: "4 day", source: "gym", assigned: 18 },
    { title: "PPL · 6 day", level: "Advanced", duration: "6 day", source: "gym", assigned: 12 },
    { title: "Upper/Lower", level: "Beginner", duration: "4 day", source: "preset", assigned: 7 },
    { title: "Full body · 3 day", level: "Beginner", duration: "3 day", source: "preset", assigned: 22 },
    { title: "5x5 Strength", level: "Intermediate", duration: "3 day", source: "preset", assigned: 9 },
    { title: "Bro split", level: "Intermediate", duration: "5 day", source: "preset", assigned: 4 }
  ],

  exercises: [
    { name: "Bench Press", group: "Chest", equipment: "Barbell" },
    { name: "Squat", group: "Legs", equipment: "Barbell" },
    { name: "Deadlift", group: "Back", equipment: "Barbell" },
    { name: "Overhead Press", group: "Shoulders", equipment: "Barbell" },
    { name: "Pull-up", group: "Back", equipment: "Bodyweight" },
    { name: "Incline DB Press", group: "Chest", equipment: "Dumbbell" }
  ],

  packages: [
    { name: "Monthly Drop-in", price: 1999, months: 1, members: 38, active: true },
    { name: "Quarterly Strength", price: 5499, months: 3, members: 64, active: true },
    { name: "Half-year PT", price: 18500, months: 6, members: 41, active: true },
    { name: "Annual Pro", price: 14999, months: 12, members: 86, active: true },
    { name: "Annual + PT", price: 22000, months: 12, members: 18, active: true }
  ],

  payments: [
    { who: "Ananya Bose", plan: "Half-year PT", amount: 18500, mode: "Cash", date: "Today", status: "pending" },
    { who: "Aryan Nair", plan: "Annual + PT", amount: 22000, mode: "UPI", date: "Today", status: "pending" },
    { who: "Tanvi Shetty", plan: "Monthly", amount: 1999, mode: "Card", date: "Yesterday", status: "pending" },
    { who: "Rohan Mehta", plan: "Annual Pro", amount: 14999, mode: "UPI", date: "20 May", status: "approved" }
  ],

  trainers: [
    { name: "Priya Nair", initials: "PN", role: "Head Coach", members: 14, sessionsToday: 3, color: 1 },
    { name: "Vikram Iyer", initials: "VI", role: "Strength Coach", members: 10, sessionsToday: 2, color: 2 }
  ],

  ptSessions: [
    { time: "06:30", member: "Aanya Sharma", trainer: "Priya N.", focus: "Bench technique", status: "completed" },
    { time: "08:00", member: "Vihaan Gupta", trainer: "Vikram I.", focus: "Squat 1RM test", status: "in_progress" },
    { time: "10:00", member: "Sara D'Souza", trainer: "Priya N.", focus: "Mobility flow", status: "upcoming" },
    { time: "17:30", member: "Aryan Nair", trainer: "Vikram I.", focus: "Deadlift form", status: "upcoming" },
    { time: "19:00", member: "Ishaan Kapoor", trainer: "Priya N.", focus: "Push day coaching", status: "upcoming" }
  ],

  gyms: [
    { name: "Titan Strength · Bandra", city: "Mumbai", members: 247, status: "active", owner: "Priya N." },
    { name: "Titan Strength · Andheri", city: "Mumbai", members: 198, status: "active", owner: "Karan M." },
    { name: "Iron House", city: "Bengaluru", members: 312, status: "active", owner: "Reyansh P." },
    { name: "Prana Studios", city: "Pune", members: 84, status: "active", owner: "Anita K." },
    { name: "Body Lab", city: "Delhi", members: 156, status: "trial", owner: "Yash B." },
    { name: "Axis Gym", city: "Hyderabad", members: 0, status: "archived", owner: "—" }
  ],

  inbox: [
    { kind: "new_gym", title: "New gym signup: Sri Shakthi Hanuman Gym", who: "K. Karthik", at: "2h ago" },
    { kind: "support", title: "Payment integration help — Iron House", who: "Reyansh P.", at: "4h ago" },
    { kind: "feedback", title: "Feature request: bulk SMS reminders", who: "Priya N.", at: "yesterday" },
    { kind: "report", title: "Member reported app crash", who: "Aanya S.", at: "2d ago" }
  ],

  notices: [
    { id: 1, title: "Annual fitness check-up — book your slot", date: "2d ago", pinned: true },
    { id: 2, title: "New cable stack arriving Tuesday", date: "5d ago" },
    { id: 3, title: "Holi closure on 14 March", date: "2w ago" }
  ],

  todayExercises: [
    { name: "Bench Press", sets: 4, reps: "5–8", last: 50, target: 52.5, group: "Chest" },
    { name: "Incline DB Press", sets: 3, reps: "8–10", last: 16, target: 18, group: "Chest" },
    { name: "Overhead Press", sets: 3, reps: "6–8", last: 25, target: 27.5, group: "Shoulders" },
    { name: "Lateral Raise", sets: 4, reps: "12–15", last: 8, target: 8, group: "Shoulders" },
    { name: "Triceps Pushdown", sets: 3, reps: "10–12", last: 22, target: 25, group: "Triceps" },
    { name: "OH Tricep Ext", sets: 3, reps: "10–12", last: 12, target: 12, group: "Triceps" }
  ],

  ptHistory: [
    { date: "27 May", trainer: "Priya N.", focus: "Bench technique", duration: 45, status: "completed" },
    { date: "24 May", trainer: "Priya N.", focus: "Lower body strength", duration: 60, status: "completed" },
    { date: "22 May", trainer: "Vikram I.", focus: "Form check + macros", duration: 45, status: "completed" },
    { date: "29 May", trainer: "Priya N.", focus: "Push day coaching", duration: 45, status: "upcoming" }
  ]
};
