// E2E Flow — Admin / Super Admin screens

const FA = () => window.FLOW_MOCK;

function FlowAdminChrome({ active, title, crumb, children, primaryAction = "Add gym" }) {
  const items = [
    { v: "dashboard", l: "Overview" },
    { v: "gyms", l: "Gyms", count: 12 },
    { v: "programs", l: "Programs", count: 32 },
    { v: "exercises", l: "Exercises", count: 184 },
    { v: "inbox", l: "Inbox", alert: 4 },
    { v: "billing", l: "Platform billing" }
  ];
  return (
    <div className="flow-owner">
      <aside className="flow-owner__side" style={{ background: "var(--bg-elevated)" }}>
        <div className="flow-owner__brand">
          <span className="flow-owner__brand-mark" style={{ background: "var(--text)" }}>
            <window.MIcons.Lightning size={12} />
          </span>
          <span>FitSplit <small style={{ fontSize: 9, fontWeight: 600, color: "var(--text-faint)", display: "block", letterSpacing: "0.06em" }}>SUPER ADMIN</small></span>
        </div>
        <span className="flow-owner__nav-group">PLATFORM</span>
        {items.map((it) => (
          <div key={it.v} className={`flow-owner__nav-item ${active === it.v ? "flow-owner__nav-item--on" : ""}`}>
            <span>{it.l}</span>
            {it.alert ? (
              <span className="flow-owner__nav-item-count flow-owner__nav-item-count--alert">{it.alert}</span>
            ) : it.count ? (
              <span className="flow-owner__nav-item-count">{it.count}</span>
            ) : null}
          </div>
        ))}
        <div style={{ marginTop: "auto", padding: 8, display: "flex", alignItems: "center", gap: 8, background: "var(--bg-subtle)", borderRadius: 10 }}>
          <span className="fm-avatar fm-avatar--sm fs-avatar--c4">VI</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700 }}>Vikram Iyer</div>
            <small style={{ fontSize: 10, color: "var(--text-soft)" }}>Super Admin</small>
          </div>
        </div>
      </aside>
      <div className="flow-owner__main">
        <div className="flow-owner__top">
          <div>
            <div className="flow-owner__crumb">Admin / {crumb}</div>
            <h2 className="flow-owner__title">{title}</h2>
          </div>
          <div className="flow-owner__top-right">
            <button className="flow-pill-btn flow-pill-btn--ghost">Inbox</button>
            <button className="flow-pill-btn">+ {primaryAction}</button>
          </div>
        </div>
        <div className="flow-owner__content">{children}</div>
      </div>
    </div>
  );
}

// ── Admin Dashboard ────────────────────────────────────────────────────
function FlowAdminDashboard() {
  return (
    <FlowAdminChrome active="dashboard" title="Platform overview" crumb="Overview">
      <div className="flow-grid-4">
        <div className="flow-kpi flow-kpi--brand"><small>TOTAL GYMS</small><strong>12</strong><em>11 active · 1 trial</em></div>
        <div className="flow-kpi flow-kpi--accent"><small>TOTAL MEMBERS</small><strong>2,840</strong><em>+184 this month</em></div>
        <div className="flow-kpi flow-kpi--warn"><small>MRR</small><strong>₹3.2L</strong><em>+12% MoM</em></div>
        <div className="flow-kpi flow-kpi--danger"><small>INBOX</small><strong>4</strong><em>unread support</em></div>
      </div>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1.6fr 1fr" }}>
        <div className="flow-card">
          <div className="flow-card__head"><h3>Top gyms by members</h3><span className="flow-card__link">All gyms →</span></div>
          <div className="flow-card__body flow-card__body--flush">
            {FA().gyms.filter(g => g.status === "active").slice(0, 4).map((g, i) => (
              <div key={g.name} style={{
                display: "grid", gridTemplateColumns: "30px 1.6fr 1fr 80px 80px",
                padding: "10px 14px", borderBottom: i < 3 ? "1px solid var(--border)" : "none",
                alignItems: "center", gap: 12
              }}>
                <span style={{ width: 26, height: 26, borderRadius: 7, background: ["var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)"][i], color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800 }}>
                  {g.name.split(" ").map(x => x[0]).slice(0, 2).join("")}
                </span>
                <div>
                  <strong style={{ fontSize: 12.5 }}>{g.name}</strong>
                  <small style={{ fontSize: 10.5 }}>{g.city} · {g.owner}</small>
                </div>
                <div style={{ height: 5, background: "var(--bg-subtle)", borderRadius: 999, overflow: "hidden" }}>
                  <div style={{ width: `${(g.members / 320) * 100}%`, height: "100%", background: "var(--brand)" }} />
                </div>
                <strong style={{ fontSize: 13, fontVariantNumeric: "tabular-nums" }}>{g.members}</strong>
                <span className="flow-tag flow-tag--ok">{g.status.toUpperCase()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flow-card">
          <div className="flow-card__head"><h3><window.MIcons.Bell size={12} /> Recent activity</h3></div>
          <div className="flow-card__body">
            {[
              { v: "Iron House upgraded to Studio plan", at: "1h ago" },
              { v: "New gym signup: Sri Shakthi Hanuman Gym", at: "2h ago" },
              { v: "Prana Studios crossed 100 members", at: "5h ago" },
              { v: "Body Lab trial expiring in 3 days", at: "yesterday" }
            ].map((a, i) => (
              <div key={i} style={{
                padding: "8px 0", borderBottom: i < 3 ? "1px solid var(--border)" : "none",
                fontSize: 11.5
              }}>
                <span>{a.v}</span>
                <div style={{ fontSize: 10, color: "var(--text-faint)", marginTop: 1 }}>{a.at}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </FlowAdminChrome>
  );
}
window.FlowAdminDashboard = FlowAdminDashboard;

// ── Admin Gyms ────────────────────────────────────────────────────────
function FlowAdminGyms() {
  return (
    <FlowAdminChrome active="gyms" title="Gym workspaces" crumb="Gyms" primaryAction="Add gym">
      <p className="flow-page-desc">Manage gym workspaces — add new ones, archive inactive, edit details, manage staff.</p>

      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <div style={{ flex: 1, maxWidth: 280, background: "var(--bg-subtle)", borderRadius: 8, padding: "5px 10px", display: "flex", alignItems: "center", gap: 8 }}>
          <window.MIcons.Search size={13} />
          <span style={{ fontSize: 12, color: "var(--text-soft)" }}>Search gyms…</span>
        </div>
        {["All 12", "Active 11", "Trial 1", "Archived 1"].map((c, i) => (
          <span key={c} style={{
            background: i === 0 ? "var(--text)" : "var(--bg-subtle)",
            color: i === 0 ? "var(--bg-elevated)" : "var(--text-soft)",
            padding: "5px 11px", borderRadius: 999, fontSize: 11, fontWeight: 600
          }}>{c}</span>
        ))}
      </div>

      <div className="flow-card">
        <div className="flow-card__body flow-card__body--flush">
          <div style={{
            display: "grid", gridTemplateColumns: "28px 1.6fr 1fr 80px 100px 80px 30px",
            padding: "8px 14px", background: "var(--bg-subtle)", borderBottom: "1px solid var(--border)",
            fontSize: 9.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.07em", color: "var(--text-faint)", gap: 12
          }}>
            <span></span><span>GYM</span><span>OWNER</span><span>MEMBERS</span><span>PLAN</span><span>STATUS</span><span></span>
          </div>
          {FA().gyms.map((g, i) => (
            <div key={g.name} style={{
              display: "grid", gridTemplateColumns: "28px 1.6fr 1fr 80px 100px 80px 30px",
              padding: "10px 14px", borderBottom: i < FA().gyms.length - 1 ? "1px solid var(--border)" : "none",
              alignItems: "center", gap: 12,
              opacity: g.status === "archived" ? 0.5 : 1
            }}>
              <span style={{ width: 26, height: 26, borderRadius: 7, background: ["var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)", "var(--text-soft)", "var(--bg-muted)"][i], color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800 }}>
                {g.name.split(" ").map(x => x[0]).slice(0, 2).join("")}
              </span>
              <div>
                <strong style={{ fontSize: 13 }}>{g.name}</strong>
                <small style={{ fontSize: 10.5 }}>{g.city}</small>
              </div>
              <span style={{ fontSize: 11.5 }}>{g.owner}</span>
              <strong style={{ fontSize: 12.5, fontVariantNumeric: "tabular-nums" }}>{g.members}</strong>
              <span style={{
                background: g.members > 300 ? "color-mix(in srgb, var(--gold) 18%, transparent)" : "var(--bg-subtle)",
                color: g.members > 300 ? "var(--gold)" : "var(--text-soft)",
                padding: "2px 8px", borderRadius: 5, fontSize: 10.5, fontWeight: 700, width: "fit-content"
              }}>
                {g.members > 300 ? "ENTERPRISE" : g.members > 100 ? "STUDIO" : "STARTER"}
              </span>
              <span className={`flow-tag flow-tag--${g.status === "active" ? "ok" : g.status === "trial" ? "noplan" : "neutral"}`}>
                {g.status.toUpperCase()}
              </span>
              <window.MIcons.More size={13} />
            </div>
          ))}
        </div>
      </div>
    </FlowAdminChrome>
  );
}
window.FlowAdminGyms = FlowAdminGyms;

// ── Admin Inbox ───────────────────────────────────────────────────────
function FlowAdminInbox() {
  return (
    <FlowAdminChrome active="inbox" title="Support inbox" crumb="Inbox" primaryAction="Compose">
      <p className="flow-page-desc">Support requests, feature suggestions, and incident reports from gym owners.</p>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1fr 1.4fr" }}>
        <div className="flow-card">
          <div className="flow-card__head"><h3>Threads ({FA().inbox.length})</h3></div>
          <div className="flow-card__body flow-card__body--flush">
            {FA().inbox.map((m, i) => (
              <div key={i} style={{
                padding: "10px 14px", borderBottom: i < FA().inbox.length - 1 ? "1px solid var(--border)" : "none",
                cursor: "pointer", background: i === 0 ? "color-mix(in srgb, var(--brand) 6%, transparent)" : "transparent"
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                  <strong style={{ fontSize: 12 }}>{m.who}</strong>
                  <small style={{ fontSize: 10, color: "var(--text-faint)" }}>{m.at}</small>
                </div>
                <div style={{ fontSize: 11.5, color: "var(--text-soft)", marginBottom: 4 }}>{m.title}</div>
                <span className={`flow-tag flow-tag--${m.kind === "support" ? "expired" : m.kind === "feedback" ? "noplan" : m.kind === "new_gym" ? "ok" : "expiring"}`}>
                  {m.kind === "support" ? "SUPPORT" : m.kind === "feedback" ? "FEATURE REQ" : m.kind === "new_gym" ? "NEW SIGNUP" : "INCIDENT"}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="flow-card">
          <div className="flow-card__head" style={{ flexDirection: "column", alignItems: "flex-start", gap: 4 }}>
            <h3>Re: Payment integration help — Iron House</h3>
            <span style={{ fontSize: 11, color: "var(--text-soft)" }}>Reyansh P. · 4h ago</span>
          </div>
          <div className="flow-card__body">
            <div style={{
              background: "var(--bg-subtle)", borderRadius: 10, padding: 12,
              fontSize: 12, lineHeight: 1.5, marginBottom: 10
            }}>
              Hi team, we're trying to enable UPI payments on our gym workspace. The settings show "Pending approval" but we submitted KYC docs 3 days ago. Can someone follow up? Members are getting frustrated.
            </div>
            <div style={{
              background: "color-mix(in srgb, var(--brand) 8%, var(--bg-elevated))",
              border: "1px solid color-mix(in srgb, var(--brand) 20%, var(--border))",
              borderRadius: 10, padding: 12, marginBottom: 12
            }}>
              <small style={{ fontSize: 10, fontWeight: 700, color: "var(--brand)", letterSpacing: "0.07em", textTransform: "uppercase" }}>YOUR REPLY DRAFT</small>
              <div style={{ fontSize: 12, marginTop: 4, lineHeight: 1.4 }}>
                Hey Reyansh — KYC was approved this morning. UPI is now live on your workspace. Let me know if you hit any other snags.
              </div>
            </div>
            <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
              <button className="flow-pill-btn flow-pill-btn--ghost">Save draft</button>
              <button className="flow-pill-btn">Send reply</button>
            </div>
          </div>
        </div>
      </div>
    </FlowAdminChrome>
  );
}
window.FlowAdminInbox = FlowAdminInbox;

// ── Admin Programs Catalog (preset library) ─────────────────────────────
function FlowAdminPrograms() {
  return (
    <FlowAdminChrome active="programs" title="Preset program catalog" crumb="Programs" primaryAction="New preset">
      <p className="flow-page-desc">Master library of presets available to all gyms. Edit to update across the platform.</p>

      <div className="flow-grid-4">
        <div className="flow-kpi flow-kpi--brand"><small>PRESETS</small><strong>32</strong></div>
        <div className="flow-kpi"><small>GYMS USING</small><strong>11/12</strong></div>
        <div className="flow-kpi flow-kpi--accent"><small>MOST POPULAR</small><strong>PPL · 6 day</strong></div>
        <div className="flow-kpi flow-kpi--warn"><small>NEW REQUESTS</small><strong>3</strong></div>
      </div>

      <div className="flow-grid-3">
        {FA().programs.concat(FA().programs.slice(0, 2)).map((p, i) => (
          <div key={i} className="flow-card" style={{ padding: 0 }}>
            <div style={{
              height: 50, background: `linear-gradient(135deg, ${["var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)", "var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)"][i]}, color-mix(in srgb, ${["var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)", "var(--brand)", "var(--accent)", "var(--gold)", "var(--danger)"][i]} 50%, transparent))`,
              padding: 10, color: "white", position: "relative"
            }}>
              <div style={{ position: "absolute", bottom: 6, left: 10, fontWeight: 700, fontSize: 12 }}>{p.title}</div>
            </div>
            <div style={{ padding: "8px 12px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10.5 }}>
                <span style={{ color: "var(--text-soft)" }}>{p.level} · {p.duration}</span>
                <strong>{p.assigned + i * 4} gyms</strong>
              </div>
            </div>
          </div>
        ))}
      </div>
    </FlowAdminChrome>
  );
}
window.FlowAdminPrograms = FlowAdminPrograms;

// ── Admin Gym Detail ──────────────────────────────────────────────────
function FlowAdminGymDetail() {
  return (
    <FlowAdminChrome active="gyms" title="Iron House · Bengaluru" crumb="Gyms / Iron House" primaryAction="Suspend workspace">
      <div className="flow-card">
        <div className="flow-card__body" style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 18, alignItems: "center" }}>
          <span style={{ width: 60, height: 60, borderRadius: 14, background: "linear-gradient(135deg, var(--gold), color-mix(in srgb, var(--gold) 50%, transparent))", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 22 }}>IH</span>
          <div>
            <h2 className="flow-h2" style={{ fontSize: 22 }}>Iron House</h2>
            <p className="flow-page-desc">Bengaluru, KA · owned by Reyansh Pillai · joined Jan 2024</p>
            <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
              <span className="flow-tag flow-tag--ok">ACTIVE</span>
              <span className="flow-tag" style={{ background: "color-mix(in srgb, var(--gold) 18%, transparent)", color: "var(--gold)" }}>ENTERPRISE</span>
              <span className="flow-tag flow-tag--neutral">312 MEMBERS</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <button className="flow-pill-btn flow-pill-btn--ghost">Impersonate owner</button>
            <button className="flow-pill-btn flow-pill-btn--ghost">Edit details</button>
          </div>
        </div>
      </div>

      <div className="flow-grid-4">
        <div className="flow-kpi flow-kpi--brand"><small>MEMBERS</small><strong>312</strong><em>+18 this month</em></div>
        <div className="flow-kpi flow-kpi--accent"><small>TRAINERS</small><strong>4</strong></div>
        <div className="flow-kpi"><small>MRR</small><strong>₹62k</strong><em>billed monthly</em></div>
        <div className="flow-kpi flow-kpi--warn"><small>SUPPORT TICKETS</small><strong>1</strong><em>open</em></div>
      </div>

      <div className="flow-grid-2" style={{ gridTemplateColumns: "1fr 1fr" }}>
        <div className="flow-card">
          <div className="flow-card__head"><h3>Staff</h3></div>
          <div className="flow-card__body flow-card__body--flush">
            {[
              { name: "Reyansh Pillai", role: "Owner", initials: "RP" },
              { name: "Anaisha Kohli", role: "Head Coach", initials: "AK" },
              { name: "Karthik Reddy", role: "Trainer", initials: "KR" },
              { name: "Yash Bhatt", role: "Trainer", initials: "YB" }
            ].map((p, i) => (
              <div key={p.name} style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "8px 14px", borderBottom: i < 3 ? "1px solid var(--border)" : "none"
              }}>
                <span className={`fm-avatar fm-avatar--sm fs-avatar--c${i + 1}`}>{p.initials}</span>
                <div style={{ flex: 1 }}>
                  <strong style={{ fontSize: 12.5 }}>{p.name}</strong>
                  <div style={{ fontSize: 10.5, color: "var(--text-soft)" }}>{p.role}</div>
                </div>
                <window.MIcons.More size={13} />
              </div>
            ))}
          </div>
        </div>
        <div className="flow-card">
          <div className="flow-card__head"><h3>Billing</h3></div>
          <div className="flow-card__body" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              { l: "Plan", v: "Enterprise (custom)" },
              { l: "Billing email", v: "billing@ironhouse.in" },
              { l: "Next renewal", v: "1 June 2026 · ₹62,400" },
              { l: "Payment method", v: "Bank transfer · NACH" }
            ].map((row) => (
              <div key={row.l} style={{
                display: "flex", justifyContent: "space-between",
                padding: "6px 0", borderBottom: "1px solid var(--border)", fontSize: 12
              }}>
                <span style={{ color: "var(--text-soft)" }}>{row.l}</span>
                <strong style={{ fontWeight: 700 }}>{row.v}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>
    </FlowAdminChrome>
  );
}
window.FlowAdminGymDetail = FlowAdminGymDetail;
